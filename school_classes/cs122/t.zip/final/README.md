# Steps
1. Initialize database with `python init_db.py` or `python3 init_db.py` in terminal
2. Export flask app with `export FLASK_APP=app` in terminal
3. Run `flask run` in terminal
4. Open `http://127.0.0.1:5000/` on web