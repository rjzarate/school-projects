package size;

public class RedGiant extends Star{
	
	RedGiant(double mass){ super(mass);}

}
