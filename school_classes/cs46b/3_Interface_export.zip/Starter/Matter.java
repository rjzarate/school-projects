package size;

public interface Matter {
	
	double getWeightPounds();
	double getMassKgs();

}
