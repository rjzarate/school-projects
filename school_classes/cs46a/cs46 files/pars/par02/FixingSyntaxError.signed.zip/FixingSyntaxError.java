/**
 * A class for fixing syntax errors.
 * 
 * 
 * Step 1: Enter your name for @author and today's date for @version
 * @author Froilan Zarate
 * @version August 31, 2022
 */
public class FixingSyntaxError
{
    public static void main(String[] args)
    {
        // Step 2: Fix the syntax errors in the following statements
        //         Do not add or remove any statements
        System.out.println("Hello"); 
        System.out.println("Hello");
        System.out.println("Hello");
        System.out.println();
        System.out.println("Hello");
        System.out.println("Hello");
    }
}

