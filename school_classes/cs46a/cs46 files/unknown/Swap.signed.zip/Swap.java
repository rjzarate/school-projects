import java.util.*;
/**
 * Swappping adjacent neighbors of an array of even length.
 *
 * @author  Alan Xiao
 * @version 2022-11-02
 */
public class Swap
{
    public static void main(String[] args)
    {
        // Create a random generator with a given seed
        int seed = 54321;           
        Random generator = new Random(seed);
        
        // Make an array of even length between 10 and 20
        int length = 10 + 2 * generator.nextInt(6);
        int[] numbers = new int[length];
        
        // Fill the array with random numbers between 0 and 99
        for (int i = 0; i < length; i++) 
            numbers[i] = generator.nextInt(100);

        // Display all array elements before swapping
        System.out.println(Arrays.toString(numbers));

        // Swap adjacent neighbors
        for (int i = 0; i < length; i = i + 2)
        {
           int temp = numbers[i];
           numbers[i] = numbers[i + 1];
           numbers[i + 1] = temp;
        }

        // Display all array elements after swapping
        System.out.println(Arrays.toString(numbers));
   }
}

