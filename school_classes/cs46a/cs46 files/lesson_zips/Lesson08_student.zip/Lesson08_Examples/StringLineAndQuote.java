import java.util.Scanner;
/**
 * A Java program to input strings and call String methods.
 *
 * @author  Qi Yang
 * @version 2022-09-20
 */
public class StringLineAndQuote
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter multiple words separated by single spaces: ");
        String line = in.nextLine();
    
        System.out.println("The original line: " + line);
        
        System.out.print("Enter a single word: ");
        String word = in.next();
        
        System.out.println("The original word: " + word);
        
        // This does not work!
        //System.out.println("The original line within quotes: "" + line + """);
        //System.out.println("The original word within quotes: "" + word + """);

        // Use the escape character
        System.out.println("The original line within quotes: \"" + line + "\"");
        System.out.println("The original word within quotes: \"" + word + "\"");
    }
}
