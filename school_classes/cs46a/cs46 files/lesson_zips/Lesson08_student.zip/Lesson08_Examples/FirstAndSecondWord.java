import java.util.Scanner;
/**
 * A Java program to input strings and call String methods.
 *
 * @author  Qi Yang
 * @version 2022-02-24
 */
public class FirstAndSecondWord
{
    public static void main(String[] args)
    {
        String courseTitle = "Introduction to Programming";
        
        int firstSpace = courseTitle.indexOf(' ');
        String firstWord = courseTitle.substring(0, firstSpace);
        System.out.printf("First word of \"%s\" is \"%s\".\n", 
                            courseTitle, firstWord);
                            
        int secondSpace = courseTitle.indexOf(" ", firstSpace + 1);
        String secondWord = courseTitle.substring(firstSpace + 1, secondSpace);
        System.out.printf("Second word of \"%s\" is \"%s\".%n", 
                            courseTitle, secondWord);
    }
}
