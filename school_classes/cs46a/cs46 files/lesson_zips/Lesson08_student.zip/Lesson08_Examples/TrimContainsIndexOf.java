import java.util.Scanner;
/**
 * A Java program to input strings and call String methods.
 *
 * @author  Qi Yang
 * @version 2022-02-24
 */
public class TrimContainsIndexOf
{
    public static void main(String[] args)
    {
        String line = "  CS 46A in Java  ";
        String word = "CS";
        
        String lineTrimmed = line.trim();
        System.out.println("The line with spaces trimmed from both ends: \"" +
                           lineTrimmed + "\"");

        word = word.trim();
        System.out.println("The word with spaces trimmed from both ends: \"" +
                           word + "\"");

        boolean trueOrFalse = line.contains(word);
        System.out.println("The line contains \"" + word + "\": " + trueOrFalse);
    
        trueOrFalse = line.contains(word.toLowerCase());
        System.out.println("The line contains \"" + word.toLowerCase() +
                        "\": " + trueOrFalse);

        int pos = line.indexOf(word);
        System.out.println("The index of the word in the original line: " + pos);
    
        pos = lineTrimmed.indexOf(word);
        System.out.println("The index of the word in the trimmed line: " + pos);
    }
}
