import java.util.Scanner;
/**
 * A Java program to input strings and call String methods.
 *
 * @author  Qi Yang
 * @version 2022-02-24
 */
public class SubStrProg
{
    public static void main(String[] args)
    {
        String course = "CS 46A";
        
        System.out.println(course.substring(1));
        // Output: S 46A
        
        System.out.println(course.substring(1, 2));
        // Output: S
        
        System.out.println(course.substring(1, 4));
        // Output: S 4
        
        // Run time error!
        //System.out.println(course.substring(-1, 3));
        
        String courseTitle = "Introduction to Programming";
        int index = 5;
        int size = 3;
        
        String str;
        str = courseTitle.substring(index, index + size);
        System.out.println(str);
        str = courseTitle.substring(index, index + size + 1);
        System.out.println(str);
        str = courseTitle.substring(index, index + size - 1);
        System.out.println(str);
    }
}
