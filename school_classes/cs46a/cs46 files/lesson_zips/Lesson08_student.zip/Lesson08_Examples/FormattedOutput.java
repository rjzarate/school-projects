/**
 * A Java program to practice formatted output.
 * 
 * @author  Qi Yang
 * @version 2022-09-20
   */
public class FormattedOutput
{
    public static void main(String[] args)
    {
        int intNum = 5;
        System.out.println("The square root of " + intNum + 
                           " is " + Math.sqrt(intNum) + ".");

        System.out.printf("The square root of %d is %f.\n",
                          intNum, Math.sqrt(intNum));
                          
        System.out.printf("The square root of %d is %.14f.\n",
                          intNum, Math.sqrt(intNum));

        System.out.printf("The square root of %d is %.2f.\n",
                          intNum, Math.sqrt(intNum));
                          
        System.out.printf("The square root of %d is %7.2f.\n",
                          intNum, Math.sqrt(intNum));
    }
}
