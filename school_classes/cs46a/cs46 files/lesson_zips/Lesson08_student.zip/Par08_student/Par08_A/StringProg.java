// Step 1: Import Java class Scanner

/**
 * A program to input, process, and output strings.
 * 
 * Note: Codecheck will use different input strings to test
 * the program, and you must use the specified variables in 
 * your program.
 *
 * Step 2: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class StringProg
{
    public static void main(String[] args)
    {
        // Step 3: Create a new Scanner object
        
        
        // Step 4: Display a prompt "Enter multiple words on one line separated by single spaces: "
        
    
        // Step 5: Read in one line of input and store it in a variable line
        
    
        // Step 6: Ask for a word with prompt "Enter a single word: "
        

        // Step 7: Read in a single string and store it in variable word
        
        
        // Step 8: Display line on one line within double quotes
        //         with message "The original line: "
        
        
        // Step 9: Display word on one line within double quotes
        //         with message "The original word: "
        
        
        // Step 10: Trime spaces from both ends of line and save it back to line
        
        
        // Step 11: Display line on one line within double quotes
        //         with message "The line with spaces trimmed from both ends: "
        
        
        // Step 12: Trime spaces from both ends of word and save it back to word
        
        
        // Step 13: Display word on one line within double quotes
        //          with message "The word with spaces trimmed from both ends: "
        
        
        // Step 14: Find out if line contains word and assign 
        //          the result to a variable trueOrFalse 
        
        
        // Step 15: Display the value of trueOrFalse on one line
        //          with message "The line contains the word: "
        

        // Step 16: Find out the index of word within line and assign
        //          the result to an integer variable pos
        
        
        // Step 17: Display the value of pos on one line
        //          with message "The index of word in line: "
        

        // Step 18: Find out the index of the first space 
        //          within line and assign it to pos
        
        
        // Step 19: Display the first word of line on one line
        //          within double quotes with message
        //          "First word of line: "
        

        // Step 20: Find out the index of the second space within
        //          line and assign it to another int variable
        
        
        // Step 21: Display the second word of line 
        //          within double quotes with message
        //          "Second word of line: "
        
    }
}
