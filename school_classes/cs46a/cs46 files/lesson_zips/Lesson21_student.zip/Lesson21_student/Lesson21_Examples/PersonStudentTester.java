/**
 * A tester program for super class Person 
 * and sub-class Student.
 *
 * @author  Qi Yang
 * @version 2022-11-17
 */
public class PersonStudentTester
{
    public static void main(String[] args)
    {
        Person aPerson = new Person("Tom", "Scanlan");

        Faculty aFaculty = new Faculty("Qi", "Yang");
        
        Student aStudent = new Student("Joe", "Clifton", 3.95);
        
        System.out.println(aPerson.getFirstName() + ", " + 
                aPerson.getLastName());
        System.out.println(aFaculty.getFirstName() + ", " + 
                aFaculty.getLastName());
        System.out.println(aStudent.getFirstName() + ", " + 
                aStudent.getLastName() + ": " + aStudent.getGpa());
        
        System.out.println(aPerson.toString());
        System.out.println(aFaculty.toString());
        System.out.println(aStudent.toString());
        
        aPerson.setFirstName("Mike");
        aFaculty.setFirstName("Frank");
        aStudent.setFirstName("Jason");

        System.out.println(aPerson.getFirstName() + ", " + 
                aPerson.getLastName());
        System.out.println(aFaculty.getFirstName() + ", " + 
                aFaculty.getLastName());
        System.out.println(aStudent.getFirstName() + ", " + 
                aStudent.getLastName() + ": " + aStudent.getGpa());
        
        System.out.println(aPerson.toString());
        System.out.println(aFaculty.toString());
        System.out.println(aStudent.toString());
    }
}
