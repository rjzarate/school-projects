/**
 * A class to model students with a first name, a last name,
 * and a gpa.
 *
 * @author  Qi Yang
 * @version 2022-11-17
 */
public class Student extends Person
{
    private double gpa;

    /**
     * Constructor for objects of class Student
     */
    public Student(String first, String last, double gpa)
    {
        super(first, last);
        this.gpa = gpa;
    }

    /**
     * Gets the gpa of this student.
     *
     * @return the gpa of this student
     */
    public double getGpa()
    {
        return gpa;
    }
    
    /**
     * Sets the gpa of this student.
     *
     * @param newGpa the new gpa of this student
     */
    public void setGpa(double newGpa)
    {
        gpa = newGpa;
    }

    /**
     * Overrides method toString()
     * 
     * @return a string of the following format
     */
    @Override
    public String toString()
    {
        return "Student(" + getFirstName() + " " + getLastName() + 
                ": gpa=" + gpa + ")";
        
    }
}
