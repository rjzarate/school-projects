/**
 * A class to model persons with a first name 
 * and a last name.
 *
 * @author  Qi Yang
 * @version 2022-11-17
 */
public class Person
{
    private String firstName;
    private String lastName;

    /**
     * Constructor for objects of class Person
     */
    public Person(String firstName, String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Gets the first name.
     *
     * @return the first name of this person
     */
    public String getFirstName()
    {
        return firstName;
    }
    
    /**
     * Gets the last name.
     *
     * @return the last name of this person
     */
    public String getLastName()
    {
        return lastName;
    }
    
    /**
     * Sets the first name.
     *
     * @param newFirstName the new first name of this person
     */
    public void setFirstName(String newFirstName)
    {
        firstName = newFirstName;
    }
    
    /**
     * Sets the last name.
     *
     * @param newLastName the new last name of this person
     */
    public void setLastName(String newLastName)
    {
        lastName = newLastName;
    }
    
    /**
     * Overrides method toString()
     * 
     * @return a string of the following format
     */
    @Override
    public String toString()
    {
        return "Person(" + firstName + " " + lastName + ")";
    }
}
