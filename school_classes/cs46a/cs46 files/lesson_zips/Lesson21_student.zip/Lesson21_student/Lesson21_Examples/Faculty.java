/**
 * A class models faculty members.
 *
 * @author  Qi Yang
 * @version 2022-11-17
 */
public class Faculty extends Person
{
    public Faculty(String first, String last)
    {
        super(first, last);
    }
}
