/**
 * Using a while loop to compute the years
 * to reach a balance target.
 *
 * @author  Qi Yang
 * @version 2022-10-04
 */
public class TargetBalance
{
    public static void main(String[] args)
    {
        double balance = 10000, rate = 0.01, target = 11000;
        
        System.out.printf("The initial balance: $%.2f.\n", balance);
        System.out.printf("The annual interest rate: %.2f%s.\n", rate * 100, "%");
        System.out.printf("The target balance: $%.2f.\n", target);

        int years = 0;
        while(balance < target)
        {
            years ++;
            double interest = balance * rate;
            balance += interest;
        }
        
        System.out.printf("After %d years, the balance will be $%.2f.\n", 
                           years, balance);
    }
}
