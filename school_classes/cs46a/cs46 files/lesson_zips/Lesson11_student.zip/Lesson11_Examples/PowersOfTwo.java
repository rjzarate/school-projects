import java.util.Scanner;
/**
 * Using a while loop to print the powers of two for
 * powers in the range of [0, limit), where limit is
 * an input positive integer.
 *
 * @author  Qi Yang
 * @version 2022-10-04
 */
public class PowersOfTwo
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        if (!in.hasNextInt())
        {
            String input = in.next();
            System.out.printf("Not an integer: %s.%n", input);
            return;
        }
        
        int limit = in.nextInt();
        
        int exp = 0; 
        while (exp < limit)
        {
            System.out.print((int)Math.pow(2, exp) + ", ");
            exp ++;
        }
        
        System.out.println();
        
        for (int power = 0; power < limit; power ++)
        {
            System.out.print((int)Math.pow(2, power) + ", ");
        }
    }
}
