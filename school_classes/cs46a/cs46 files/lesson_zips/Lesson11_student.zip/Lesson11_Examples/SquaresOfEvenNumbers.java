import java.util.Scanner;
/**
 * Print the squares of all even numbers in the range of
 * [2, limit], where limit is an input positive integer.
 *
 * @author  Qi Yang
 * @version 2022-10-04
 */
public class SquaresOfEvenNumbers
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        if (!in.hasNextInt())
        {
            String input = in.next();
            System.out.printf("Not an integer: %s.%n", input);
            return;
        }

        int limit = in.nextInt();
        
        for (int base = 2; base <= limit; base += 2)
        {
            System.out.print((int)Math.pow(base, 2) + ", ");
        }

        System.out.println();
        
        int base = 2;
        while (base <= limit)
        {
            System.out.print((int)Math.pow(base, 2) + ", ");
            base += 2;
        }
                        
    }
}
