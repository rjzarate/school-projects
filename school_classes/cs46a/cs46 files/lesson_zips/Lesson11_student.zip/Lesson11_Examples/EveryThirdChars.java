import java.util.Scanner;
/**
 * Reads in a line of input then prints out a string 
 * consisting of every third chars of the input line,
 * starting from the beginning.
 *
 * @author  Qi Yang
 * @version 2022-10-04
 */
public class EveryThirdChars
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String input = in.next();

        String output = "";
        for (int i = 0; i < input.length(); i += 3)
            output += input.charAt(i);
                    
        System.out.println("Every third chars: " + output);

        output = "";
        int index = 0;
        while (index < input.length())
        {
            //output += input.substring(index, index + 1);
            output += input.charAt(index);
            index += 3;
        }

        System.out.println("Every third chars: " + output);
    }
}
