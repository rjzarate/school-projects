import java.util.Scanner;
/**
 * A Java program to calculate the payment for an ice cream shop.
 * There are two types of ice cream, Plain and Waffle, and each
 * type is sold for one or two scoops.
 * 
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class IceCreamShop
{
    public static final double ONE_SCOOP_PLAIN_CONE = 1.75;
    public static final double ONE_SCOOP_WAFFLE_CONE = 2.50;  
    public static final double TWO_SCOOP_PLAIN_CONE = 2.25;
    public static final double TWO_SCOOP_WAFFLE_CONE = 2.75;
    public static final int PLAIN_CONE = 1;
    public static final int WAFFLE_CONE = 2;
      
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter 1 for Plain or 2 for Waffle: ");
        
        // Step 2: Fill in the if condition that the next
        //         input token is not an integer
        if ( )
        {
            // Step 3: Read in the next input to a string variable
            
            
            // Step 4: Display a message on one line
            // Sample message (assuming the input was "two")
            // Invalid type: two
            
            
            // Step 5: Display the following meesage on one line
            // Program terminated.
            
            
            // Step 6: Terminate the program
            
        }
        
        // Step 7: Read in the next integer to an int variable
        

        // Step 8: Fill in the condition that the input
        //         number is less than 1 or larger than 2
        if ()   
        {
            // Step 9: Display a message on one line
            // Sample message (assuming the input was 3)
            // Invalid type: 3
            
            
            // Step 10: Display the following meesage on one line
            // Program terminated.
            
            
            // Step 11: Terminate the program
            
        }
        
        System.out.print("How many scoops (1 or 2): ");
        
        // Step 12: Fill in the if condition that the next
        //          input token is not an integer
        if (  )
        {
            // Step 13: Read in the next input to a string variable
            
            
            // Step 14: Display a message on one line
            // Sample message (assuming the input was "two")
            // Invalid scoops: two
            
            
            // Step 15: Display the following meesage on one line
            // Program terminated.
            
            
            // Step 16: Terminate the program
            
        }
        
        // Step 17: Read in the next integer to an int variable
        

        // Step 18: Fill in the condition that the input
        //          number is less than 1 or larger than 2
        if (  )
        {
            // Step 19: Display a message on one line
            // Sample message (assuming the input was 3)
            // Invalid type: 3
            
            
            // Step 20: Display the following meesage on one line
            // Program terminated.
            
            
            // Step 21: Terminate the program
            
        }
        
        double payment = 0;

        // Step 22: Use nested if statements to calculate 
        //          the payment using the defined constants.
        // ONE_SCOOP_PLAIN_CONE = 1.75;
        // ONE_SCOOP_WAFFLE_CONE = 2.50;  
        // TWO_SCOOP_PLAIN_CONE = 2.25;
        // TWO_SCOOP_WAFFLE_CONE = 2.75;
        // PLAIN_CONE = 1
        // WAFFLE_CONE = 2

        
                
        // Step 23: Display the payment with a dollar sign and
        //          two decimal digits

    }
}
