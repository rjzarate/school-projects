/**
 * A tax return of a taxpayer in 2008.
 * 
 * @Author: Qi Yang
 * @version 2022-09-27
 */

public class TaxReturn
{
    public static final int SINGLE = 1;
    public static final int MARRIED = 2;

    public static final double RATE1 = 0.10;
    public static final double RATE2 = 0.25;
    public static final double SINGLE_LIMIT = 32000;
    public static final double MARRIED_LIMIT = 64000;

    private double income;
    private int status;

    /**
     * Constructs a TaxReturn object for a given income 
     * and marital status.
     * 
     * @param anIncome the amount of income
     * @param aStatus either SINGLE or MARRIED
     */
    public TaxReturn(double anIncome, int aStatus)
    {
        income = anIncome;
        status = aStatus;
    }

    /**
     * Computes and returns the amount of tax for
     * the givem income and marital status.
     * 
     * @return the amount of tax
     */
    public double getTax()
    {
        double tax;
        if (status == SINGLE)
        {
            if (income <= SINGLE_LIMIT)
            {
                tax = income * RATE1;
            }
            else
            {   
                tax = SINGLE_LIMIT * RATE1 + 
                     (income - SINGLE_LIMIT) * RATE2;
            }
        }
        else
        {
            if (income <= MARRIED_LIMIT)
            {
                tax = income * RATE1;
            }
            else
            {
                tax = MARRIED_LIMIT * RATE1 + 
                     (income - MARRIED_LIMIT) * RATE2;   
            }
        }
        return tax;
    }
}
