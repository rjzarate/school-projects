import java.util.Scanner;
/**
 * This program calculates a simple tax return.
 * 
 * @author  Qi Yang
 * @version 2022-09-27
 */
public class TaxCalculator
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);

        System.out.print("Please enter your status (1 for single, 2 for married): ");
        if (!in.hasNextInt())
        {
            String input = in.next();
            System.out.printf("Invalid status: %s%n", input);
            System.out.println("Program terminated.");
            return;
        }
        
        int status = in.nextInt();
        if (status != 1 && status != 2)
        {
            System.out.printf("Invalid status: %d%n", status);
            System.out.println("Program terminated.");
            return;
        }

        System.out.print("Please enter your income: ");
        if (!in.hasNextDouble())
        {
            String input = in.next();
            System.out.printf("Invalid income: %s%n", input);
            System.out.println("Program terminated.");
            return;
        }

        double income = in.nextDouble();
        
        if (income <= 0)
        {
            System.out.printf("Invalid income: %.2f%n", income);
            System.out.println("Program terminated.");
            return;
        }

        TaxReturn taxReturn = new TaxReturn(income, status);
        System.out.printf("Your tax payment is $%.2f%n", taxReturn.getTax());
    }
}
