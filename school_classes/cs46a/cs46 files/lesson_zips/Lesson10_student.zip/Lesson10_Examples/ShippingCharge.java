import java.util.Scanner;
/**
 * Calculate the shipping charge based on the country
 * and state if in USA.
 *
 * @author  Qi Yang
 * @version 2022-09-27
 */
public class ShippingCharge
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        String country, state = "";
        
        System.out.print("Enter the country: ");
        country = in.next();    // "UK"
        
        if (country.equals("USA"))
        {
            System.out.print("Enter the state: ");
            state = in.next();   
        }
        
        double shipping = 5.00;     
        if (country.equals("USA"))
           if (state.equals("HI"))  
              shipping = 10.00;
        else 
           shipping = 20.00;        
        
        System.out.printf("$%.2f\n", shipping);
        
        
        if (country.equals("USA"))
        {
           if (state.equals("HI")) 
              shipping = 10.00;
        }
        else 
        {
           shipping = 20.00;
        }
        
        System.out.printf("$%.2f\n", shipping);
        
        
        double shipping2;
        if (country.equals("USA"))
        {
           if (state.equals("HI")) 
              shipping2 = 10.00;
           else
              shipping2 = 5.00;
        }
        else 
        {
           shipping2 = 20.00;
        }
        
        System.out.printf("$%.2f\n", shipping2);
        
    }
}
