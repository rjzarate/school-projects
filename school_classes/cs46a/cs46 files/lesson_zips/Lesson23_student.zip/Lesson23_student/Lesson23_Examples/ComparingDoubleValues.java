/**
 * Comparing Double values.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class ComparingDoubleValues
{
    public static void main(String[] y)
    {
        double num = 2.0;
        double root = Math.sqrt(num);
        double result = root * root;
        
        if (num == result)
            System.out.println("Equal");
        else
            System.out.println("Not Equal");
        
        System.out.println("num: " + num);
        System.out.println("result: " + result);
        System.out.println("root: " + root);

        /*
        System.out.print("Double.compare(num, result): ");
        System.out.println(Double.compare(num, result));

            
        double num1, num2;
        num1 = 8.5;
        num2 = 8.4;
        System.out.println("num1: " + num1);
        System.out.println("num2: " + num2);
        System.out.print("Double.compare(num1, num2): ");
        System.out.println(Double.compare(num1, num2));

        num1 = 10.5;
        num2 = 10.6;
        System.out.println("num1: " + num1);
        System.out.println("num2: " + num2);
        System.out.print("Double.compare(num1, num2): ");
        System.out.println(Double.compare(num1, num2));
        
        num1 = 10.59999999999999999999999998;
        num2 = 10.59999999999999999999999999;
        System.out.println("num1: 10.59999999999999999999999998");
        System.out.println("num2: 10.59999999999999999999999999");
        System.out.print("Double.compare(num1, num2): ");
        System.out.println(Double.compare(num1, num2));

        if (num1 == num2)
            System.out.println("Equal");
        else if (num1 < num2)
            System.out.println("num1 smaller");
        else
            System.out.println("num1 larger");
        */
    }
}
