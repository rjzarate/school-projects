/**
 * Models bank account objects with a string account number
 * and its balance.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class BankAccountString implements Comparable
{
    private static int lastAssignedNumber = 1000;
    
    private String accountNumber;
    private double balance;

    /**
     * Constructs an object of bank account with an amount
     * as the initial balance.
     * 
     * @param amount the initial balance of this bank account
     */
    public BankAccountString(double amount)
    {
        lastAssignedNumber ++;
        accountNumber = Integer.toString(lastAssignedNumber);
        balance = amount;
    }
    
    /**
     * Gets a string representation for this bank account.
     * 
     * @return a string with the account number and its balance
     */
    public String toString()
    {
        String s = "BankAccount[accountNumber=" + accountNumber +
                   ",balance=" + balance + "]";
            
        return s;
    }
    
    /**
     * Implements the compareTo() method for the Comparable interface.
     * 
     * @param obj the bank account object to copare to
     * @return an integer indicating the comparison result
     */
    public int compareTo(Object obj)
    {
       BankAccountString account = (BankAccountString)obj;
    
       int result = Double.compare(this.balance, account.balance);
       if (result == 0)
           result = this.accountNumber.compareTo
                                (account.accountNumber);
        
       return result;
    }
}
