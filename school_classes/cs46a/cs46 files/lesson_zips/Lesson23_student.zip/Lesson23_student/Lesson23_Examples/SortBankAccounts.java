import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/**
 * Sort an array of BankAccountString and an array list of BankAccount
 * assuming the bank account is an int.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class SortBankAccounts
{
    public static void main(String[] args)
    {
        Random generator = new Random(2021);

        ArrayList<BankAccount> list = new ArrayList<BankAccount>();
                
        list.add(new BankAccount(411));
        list.add(0, new BankAccount(379));
        list.add(0, new BankAccount(165));
        list.add(0, new BankAccount(263));
        list.add(0, new BankAccount(165));
        
        System.out.println("Before sorting:");
        System.out.println(list.toString());
        
        Collections.sort(list);
        
        System.out.println("After sorting:");
        System.out.println(list.toString());
        
        BankAccount[] array = new BankAccount[10];
        int count = 5;

        array[4] = new BankAccount(411);
        array[3] = new BankAccount(379);
        array[2] = new BankAccount(165);
        array[1] = new BankAccount(263);
        array[0] = new BankAccount(165);
        
        System.out.println("Before sorting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }

        // Sorting a partial array
        Arrays.sort(array, 0, count);
        
        System.out.println("After sorting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }

        count = 10;
        array[9] = new BankAccount(75);
        array[8] = new BankAccount(75);
        array[7] = new BankAccount(321);
        array[6] = new BankAccount(75);
        array[5] = new BankAccount(321);
        
        System.out.println("Before sorting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }

        // Sorting a full array
        Arrays.sort(array);
        
        System.out.println("After sorting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }
    }
}
