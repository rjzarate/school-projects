/**
 * Comparing integer values.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class ComparingIntegerValues
{
    public static void main(String[] y)
    {
        int num1 = Integer.MAX_VALUE / 2;
        int num2 = Integer.MIN_VALUE;
        
        int result = num1 - num2;
        
        if (result > 0)
            System.out.println("num1 is larger");
        else if (result < 0)
            System.out.println("num1 is smaller");
        else
            System.out.println("Equal");
        
        System.out.println("num1: " + num1);
        System.out.println("num2: " + num2);
        System.out.println("result: " + result);
        
        // Must use if statements to compare two integers
        // when they may not both be positive
        if (num1 > num2)
            System.out.println("num1 is larger");
        else if (num1 < num2)
            System.out.println("num1 is smaller");
        else
            System.out.println("they are equal");
    }
}
