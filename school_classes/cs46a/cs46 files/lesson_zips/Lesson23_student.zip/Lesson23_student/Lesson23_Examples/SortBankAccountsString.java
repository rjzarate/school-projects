import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/**
 * Sort an array of BankAccountString and an array list of BankAccount
 * assuming the bank account is a string.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class SortBankAccountsString
{
    public static void main(String[] args)
    {
        Random generator = new Random(202111);

        ArrayList<BankAccountString> list = new ArrayList<BankAccountString>();
        
        list.add(new BankAccountString(411));
        list.add(0, new BankAccountString(379));
        list.add(0, new BankAccountString(165));
        list.add(0, new BankAccountString(263));
        list.add(0, new BankAccountString(165));
        
        System.out.println("Before soroting:");
        System.out.println(list.toString());
        
        Collections.sort(list);
        
        System.out.println("After soroting:");
        System.out.println(list.toString());
        
        BankAccountString[] array = new BankAccountString[10];
        int count = 5;

        array[4] = new BankAccountString(411);
        array[3] = new BankAccountString(379);
        array[2] = new BankAccountString(165);
        array[1] = new BankAccountString(263);
        array[0] = new BankAccountString(165);
        
        System.out.println("Before sorting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }

        // Sorting a partial array
        Arrays.sort(array, 0, count);
        
        System.out.println("After sorting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }

        
        count = 10;
        array[9] = new BankAccountString(75);
        array[8] = new BankAccountString(75);
        array[7] = new BankAccountString(321);
        array[6] = new BankAccountString(75);
        array[5] = new BankAccountString(321);
        
        System.out.println("Before soroting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }

        // Sorting a full array
        Arrays.sort(array);
        
        System.out.println("After soroting:");
        for (int i = 0; i < count; i ++)
        {
            System.out.println(array[i].toString());
        }
    }
}
