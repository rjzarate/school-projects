/**
 * Models bank account objects with an int account number
 * and its balance.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class BankAccount implements Comparable
{
    private static int lastAssignedNumber = 1000;
    
    private int accountNumber;
    private double balance;

    /**
     * Constructs an object of bank account with an amount
     * as the initial balance.
     * 
     * @param amount the initial balance of this bank account
     */
    public BankAccount(double amount)
    {
        lastAssignedNumber ++;
        accountNumber = lastAssignedNumber;
        balance = amount;
    }
    
    /**
     * Gets a string representation for this bank account.
     * 
     * @return a string with the account number and its balance
     */
    public String toString()
    {
        String s = "BankAccount[accountNumber=" + accountNumber +
                   ",balance=" + balance + "]";
            
        return s;
    }
    
    /**
     * Implements the compareTo() method for the Comparable interface.
     * 
     * @param obj the bank account object to copare to
     * @return an integer indicating the comparison result
     */
    public int compareTo(Object obj)
    {
        BankAccount account = (BankAccount)obj;
    
        return Double.compare(this.balance, account.balance);
    }
}
