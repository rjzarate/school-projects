/**
 * Comparing string values.
 *
 * @author  Qi Yang
 * @version 2022-11-29
 */
public class ComparingStringValues
{
    public static void main(String[] y)
    {
        String s1, s2;
        int result;
        
        s1 = "hello";
        s2 = "hello";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "help";
        s2 = "hello";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "p";
        s2 = "l";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "hello";
        s2 = "help";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "l";
        s2 = "p";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "hello";
        s2 = "apple";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "h";
        s2 = "a";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "Apple";
        s2 = "apple";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "A";
        s2 = "a";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "999";
        s2 = "998";
        result = s1.compareTo(s2);
        System.out.println(result);
        
        s1 = "";
        s2 = "0";
        result = s1.compareTo(s2);
        System.out.println(result);
    }
}
