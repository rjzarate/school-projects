import java.util.ArrayList;
/**
 * The class manages a list of circles. 
 * 
 * @author  Qi Yang
 * @version 2022-10-25
 */
public class CircleList
{
    public final double LOW_LIMIT = 10.0;
    public final double HIGH_LIMIT = 20.0;
    
    private ArrayList<Circle> circleList;

    /**
     * Constructs an object of CircleList by initializing the
     * instance variable to an empty array list of Circle.
     */
    public CircleList()
    {
        circleList = new ArrayList<Circle>();
    }

    /**
     * Gets the number of circles in the list.
     * 
     * @return the number of circles in the list
     */
    public int count()
    {
        return circleList.size();
    }
    
    /**
     * Adds a Circle object at the end of the list.
     * 
     * @param circle the circle to add 
     */
    public void add(Circle circle)
    {
        circleList.add(circle);
    }

    /**
     * Gets the largest circle in the list.
     * Returns null if the list is empty.
     * 
     * @return the largest circle in the list
     */
    public Circle largestCircle()
    {
        double max = 0.0;
        Circle largest = null;
        for (Circle circle: circleList)
        {
            double area = circle.getArea();
            if (area > max)
            {
                max = area;
                largest = circle;
            }
        }
        return largest;
    }
    
    /**
     * Gets the largest circle in the list.
     * Returns null if the list is empty.
     * 
     * @return the largest circle in the list
     */
    public Circle lastGoodCircle()
    {
        Circle good = null;
        for (int i = circleList.size() - 1; i >= 0; i --)
        {
            Circle circle = circleList.get(i);
            double r = circle.getRadius();
            int x = circle.getX();
            int y = circle.getY();
            int q = x / y;
            if (r >= 10.0 && r <= 20.0 && x > 0 && y > 0 &&
                (q == 1 || q == 2))
            {
                good = circle;
                break;
            }
        }
        return good;
    }

    /**
     * Gets the largest circle in the list.
     * Returns null if the list is empty.
     * 
     * @return the largest circle in the list
     */
    public Circle firstGoodCircle()
    {
        //Circle good = null;
        for (Circle circle: circleList)
        {
            double r = circle.getRadius();
            int x = circle.getX();
            int y = circle.getY();
            int q = x / y;
            if (r >= LOW_LIMIT && r <= HIGH_LIMIT && 
                x > 0 && y > 0 && (q == 1 || q == 2))
            {
                //good = circle;
                //break;
                return circle;
            }
        }
        return null;
    }

    /**
     * Gets a string repsentation including all circles 
     * in the list by returning the string from toString()
     * method of the list.
     * 
     * @return a string repsentation for the circle list
     */
    @Override
    public String toString()
    {
        return circleList.toString();
    }
}
