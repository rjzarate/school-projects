// Step 1: import Java class ArrayList
import java.util.ArrayList;
/**
 * The class manages a list of circles. 
 * 
 * Step 2: Enter your name for @author and today's date for @version
 * @author  Qi Yang
 * @version 2020-10-25
 */
public class CircleList
{
    // Step 3: Declare an instance variable of
    //         an array list of class Circle
    private ArrayList<Circle> list;

    // Step 4: Complete the default constructor according
    //         to the comment.
    /**
     * Constructs an object of CircleList by initializing the
     * instance variable to an empty array list of Circle.
     */
    public CircleList()
    {

    }

    // Step 5: Complete method count() according to the comment,
    //         including Javadoc tags
    /**
     * Gets the number of circles in the list.
     * 
     */
    public int count()
    {
        return 0;
    }
    
    // Step 6: Complete method add() according to the comment,
    //         including Javadoc tags
    /**
     * Adds a Circle object at the end of the list.
     * 
     */
    public void add(Circle circle)
    {
        
    }

    // Step 7: Complete method averageArea() according to the comment,
    //         including Javadoc tags
    /**
     * Gets the average area of all circles in the list.
     * Returns 0 if the list is empty. Use the ehanced
     * for loop to calculate the sum of areas of all
     * circles in the list.
     * 
     */
    public double averageArea()
    {
        return 0.0;
    }   
    
    // Step 8: Complete method largestArea() according to the comment,
    //         including Javadoc tags
    /**
     * Gets the largest area among all circles in the list.
     * Returns 0.0 if the list is empty.
     * 
     */
    public double largestArea()
    {
        return 0.0;
    }
    
    // Step 9: Complete method updatingRadius() according to the comment,
    //         including Javadoc tags
    /**
     * Sets the radius of the circle at the specified index to
     * newRadius if index is valid, but do nothing otherwise.
     * 
     */
    public void updatingRadius(int index, double newRadius)
    {

    }
    
    // Step 10: Override method toString() according to the comment,
    //          including Javadoc tags
    /**
     * Gets a string representation for the list including all 
     * circles in the list by returning the string from the 
     * toString() method of the list.
     * 
     */
    @Override
    public String toString()
    {
        return null;
    }

}
