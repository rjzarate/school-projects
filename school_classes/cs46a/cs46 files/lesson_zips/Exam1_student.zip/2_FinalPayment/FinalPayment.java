// Step 1: Import class Scanner

/**
 * A Java program to calculate the discount based on
 * the amount of payment.
 *
 * Step 2: Enter your name for @author and the password for @version
 * @author  
 * @version 
 */
public class FinalPayment
{
    public static double HIGH_DISCOUNT_MIN_AMOUNT = 100.0;
    public static double HIGH_DISCOUNT_PERCENTAGE = 0.20;
    public static double NORMAL_DISCOUNT_PERCENTAGE = 0.10;
    
    public static void main(String[] args)
    {
        // Step 3: Create a Scanner object to input value from the keyboard
        
        
        // Step 4: Display an input prompt "Enter your payment: "
        
        
        // Step 5: If the next input token is not a double number
        //              Read in the next input token
        //              Display a message on one line
        //                  Sample message assuming the input is "EAGLE"
        //                  "Invalid payment: EAGLE."
        //              Terminate the program

        
        // Step 6: Read in the payment and store it in a variable

        
        // Step 7: If the input payment is not positive
        //              Display a message on one line 
        //                  Sample message assuming the input payment is -100
        //                  "Payment must be positive: -100.0."
        //              Terminated the program

        
        // Step 8: Declare a double variable discount with an initial value of 0

        
        // Step 9: If payment is at least HIGH_DISCOUNT_MIN_AMOUNT 
        //              Set discount to the product of payment and HIGH_DISCOUNT_PERCENTAGE
        //         Otherwise
        //              Set discount to the product of payment and NORMAL_DISCOUNT_PERCENTAGE

        
        // Step 10: Display the payment, the discount, and the final payment 
        //          The final payment is the difference of the original payment 
        //          and the discount
        //              Sample output 
        //              Your original payment is $99.99.
        //              Your discount is $10.00.
        //              Your final payment is $89.99.

    }
}
