/**
 * The class manages an array of Rectangle. Rectangles can be added
 * into the array and the number of rectangles in the array must be
 * kept correct at all times.
 * 
 * Step 1: Enter your name for @author and the password for @version
 * @author  
 * @version 
 */
public class RectangleArray
{
    // Step 2: Declare two instance variables to manage 
    //         an array of Rectangle
    

    // Step 3: Write the constructor according to the comment.
    //         Javadoc is required.
    /**
     * Initializes the instance variables with two
     * parameters: an array of Rectangle and a count
     * of elements in the array.
     */


    // Step 4: Write method add() according to the comment.
    //         Javadoc is required.
    /**
     * Adds a rectangle to the specified index position in the  
     * array and shifts the element at the position and all 
     * subsequent elements to the right if the array is not 
     * full and the index is valid. It does nothing otherwise.
     */
    
    
    // Step 5: Write method lastExcellentRectangle() according 
    //         to the comment. Javadoc is required.
    /**
     * Finds and returns the LAST excellent rectangle in the array.
     * It returns null if the array has no excellent rectangles.
     * A rectangle is excellent if the following conditions are true
     *          y is not 0                                  and 
     *          height is not 0                             and
     *          the remainder of x divided by y equals      
     *              the remainder of width divided by height
     *    
     * The method should stop execution and return the last 
     * perfect rectangle after it is found.
     */    
    

    /**
     * Gets a String representation for the array in the following format:
     *    [Rectangle[x=1,y=4,widht=2,height=0], Rectangle[x=5,y=2,widht=11,height=3]]
     * Notie that class Rectangle provides a method toString() that returns
     * a string for a rectangle in the format 
     *      "Rectangle[x=1,y=2,widht=3,height=3]"
     * 
     * @return a String representation for the array 
     */
    @Override
    public String toString()
    {
        String s = "[";
        if (size > 0)
        {
            for (int i = 0; i < size - 1; i ++)
                s += array[i].toString() + ", ";
                
            s += array[size - 1].toString();
        }
        
        return s + "]";
    }
}
