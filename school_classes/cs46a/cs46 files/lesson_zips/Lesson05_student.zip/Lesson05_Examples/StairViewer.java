/**
 * Draws a staircase with three rectangles.
 * You can use mgic numbers to create the rectangles.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  Qi Yang
 * @version 2022-09-06
 */
public class StairViewer
{

    public static void main(String[] args) 
    {
        // Step 2: Create a rectangle and draw it as the 
        //         top step of the stair 
        // location: (20, 10)
        // size: (20, 20)
        Rectangle topStep = new Rectangle(20, 10, 20, 20);
        topStep.draw();

        // Step 3: Create a rectangle and draw it as the 
        //         middle step of the stair 
        // location: below the top step, aligned on left
        // size: (40, 20)
        Rectangle middleStep = new Rectangle(20, 30, 40, 20);
        middleStep.draw();

        // Step 4: Create a rectangle and draw it as the 
        //         bottom step of the stair 
        // location: below the middle step, aligned on left
        // size: (60, 20)
        Rectangle bottomStep = new Rectangle(20, 50, 60, 20);
        bottomStep.draw();
    }
}
