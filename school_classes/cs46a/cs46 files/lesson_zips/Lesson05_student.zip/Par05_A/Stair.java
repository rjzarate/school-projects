/**
 * The class models 3-step stairs at any locations.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class Stair
{
    // Static constants
    public static final int STEP_HEIGHT = 20;
    public static final int STEP1_WIDTH = 20;
    public static final int WIDTH_INCREMENT = 20;
    
    // Step 2: Declare two instance variables for 
    //         the location (x, y) of this stair 


    /**
     * Initializes the instance variables to create an object
     * of class Stair.
     * 
     * @param  xPos the x-coordinate of the upper-left corner
     * @param  yPos the y-coordinate of the upper-left corner
     */
    public Stair(double xPos, double yPos)
    {
        // Step 3: Complete the constructor
        
    }

    /**
     * Gets the x coordinate of the upper-left corner
     * of this stair.
     *
     * @return the x coordinate of the upper-left corner
     */
    public double getX()
    {
        // Step 4: Complete method getX()
        return 0;
    }

    /**
     * Draws this stair at the specified location (x, y).
     */
    public void draw()
    {
        // Step 5: Complete method draw()

    }
}