/**
 * The class manages a full array of circles and provides
 * some methods to retrieve information from it. No adding
 * to or removing from the array, and the array length is the 
 * number of circles in the array.
 * 
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class CircleManager
{
    // Step 2: Declare an array of class Circle
    //         as the instance variable
    

    // Step 3: Complete the constructor according to the comment.
    /**
     * Constructs an object of CircleManager by initializing
     * the instance variable to the parameter.
     * 
     * @param circles the array of Circle to be managed
     */
    public CircleManager(Circle[] circles)
    {
        
    }

    // Step 4: Complete method maxX() according to the
    //         comment 
    /**
     * Gets the largest x value for all circles in the array.
     * 
     * You must use the enhanced for loop.
     * 
     * @return the largest x value for all circles in the array
     */
    public int maxX()
    {

        return Integer.MIN_VALUE;
    }

    // Step 5: Complete method countOfLargerThanLimit() 
    //         according to the comment
    /**
     * Gets the number of circles in the array that
     * have an area larger than the given limit.
     * 
     * You must use the enhanced for loop.
     * 
     * @param  limit the specified limit
     * @return the number of circles in the array with a
     *         area larger than the given limit.
     */
    public int countOfLargerThanLimit(double limit)
    {
        
        return 0;
    }
    
    // Step 6: Complete method averageArea() according 
    //         to the comment
    /**
     * Gets the average area of all circles in the array.
     * You can assume the length is the number of circles 
     * in the array and not zero.
     * 
     * You must use the enhanced for loop.
     * 
     * @return the average area of all circles in the array 
     */
    public double averageArea()
    {
        
        return 0.0;
    }
}
