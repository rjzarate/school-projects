import java.util.Scanner;
/**
 * Using a while loop to check the input value range.
 *
 * @author  Qi Yang
 * @version 2022-10-11
 */
public class CheckingRangeWhileLoop
{
    public static final double MIN_PAYMENT = 0.0;
    public static final double MAX_PAYMENT = 50.0;
    
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        double payment = 0;

        System.out.print("Enter a payment between 0 and 50: ");
        payment = in.nextDouble();    

        while (payment < MIN_PAYMENT || payment > MAX_PAYMENT)
        {
            System.out.printf("Out of range: %.2f%n", payment);
              
            System.out.print("Enter a payment between 0 and 50: ");
            payment = in.nextDouble();    
        }

        System.out.printf("The input payment: %.2f.\n", payment);
   }
}
