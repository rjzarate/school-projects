import java.util.Scanner;
/**
 * Using a while loop to check the input data type.
 *
 * @author  Qi Yang
 * @version 2022-10-11
 */
public class CheckingDataTypeWhileLoop
{
    public static double HIGH_DISCOUNT_MIN_AMOUNT = 100.0;
    public static double HIGH_DISCOUNT_PERCENTAGE = 0.20;
    public static double NORMAL_DISCOUNT_PERCENTAGE = 0.10;
    public static final double MIN_PAYMENT = 0.0;
    public static final double MAX_PAYMENT = 50.0;
    
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        double payment = 0;

        System.out.print("Enter your payment: ");
        while (!in.hasNextDouble())
        {
            String input = in.next();
            System.out.printf("Invalid payment: %s.%n", input);
            
            System.out.print("Enter your payment: ");
        }

        payment = in.nextDouble();    
        System.out.printf("The input payment: %.2f.\n", payment);
    }
}
