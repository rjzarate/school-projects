import java.util.Scanner;
/**
 * Using a while loop to compute the average exam score.
 * The scores are non-negative integers and the input
 * ends with a -1.
 * Sample input: 40  45  0  35  49  50  -1
 *
 * @author  Qi Yang
 * @version 2022-10-11
 */
public class AveragScoreSentinel
{
    public static final int END_OF_INPUT = -1;
    
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        double total = 0;
        int count = 0;
                        
        System.out.print("Enter a score, -1 to end input: ");
        int score = in.nextInt();   // Prime Read to initialize 
        while(score != END_OF_INPUT)
        {
            total += score;
            count ++;
            
            System.out.print("Enter a score, -1 to end input: ");
            score = in.nextInt();   // Read next value
        }
        
        if (count == 0)
            System.out.println("No scores entered.");
        else
            System.out.printf("Average of %d scores: %.2f.\n", 
                               count, total / count);
    }
}
