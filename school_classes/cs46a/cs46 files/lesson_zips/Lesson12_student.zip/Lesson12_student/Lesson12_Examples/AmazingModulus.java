import java.util.Scanner;
/**
 * Using a while loop to calculate the sum of all
 * digits of an integer.
 *
 * @author  Qi Yang
 * @version 2022-10-11
 */
public class AmazingModulus
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter an positive integer: ");
        int num = in.nextInt();     // 2022
        int sum = 0;
        while (num > 0)
        {
            int digit = num % 10;
            sum = sum + digit;
            num = num / 10;
        }
        System.out.printf("The sum of all digits: %d.%n", sum);
    }
}
