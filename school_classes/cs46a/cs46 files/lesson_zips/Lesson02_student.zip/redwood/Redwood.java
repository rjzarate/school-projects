/**
 * Load an image as a Picture object and
 * call methods on the objects.
 *
 * @author  Qi Yang
 * @version 2022-08-30
 */
public class Redwood
{
    public static void main(String[] args)
    {
        // Create an object of class Picture and
        // assign it to a variable pic
        Picture pic = new Picture("redwood.png");
    
        // Call method draw()
        pic.draw();
    
        // Call methods getX() and getY()
        System.out.println("X-coordinate: " + pic.getX());
        System.out.println("Y-coordinate: " + pic.getY());
    
        // Call methods getWidth() and getHeight()
        System.out.println("Width : " + pic.getWidth());
        System.out.println("Height: " + pic.getHeight());
        
    }
}