/**
 * A class for fixing syntax errors.
 * 
 * 
 * Step 1: Enter your name for @author and today's date for @version
 * @author 
 * @version
 */
public class FixingSyntaxError
{
    public static void main(String[] args)
    {
        // Step 2: Fix the syntax errors in the following statements
        //         Do not add or remove any statements
        System.out.printline("Hello"); 
        System.out.println(Hello);
        System.out.display("Hello");
        System.out.printLn();
        System.Out.println("Hello")
        system.println("Hello");
    }
}
