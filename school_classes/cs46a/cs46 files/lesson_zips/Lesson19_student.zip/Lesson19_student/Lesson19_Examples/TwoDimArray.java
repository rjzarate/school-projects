import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;
/**
 * Practices with 2-D arrays.
 *
 * @author  Qi Yang
 * @version 2022-11-03
 */
public class TwoDimArray
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        int rows = 3, cols = 4;
        int[][] twoDArray = new int[rows][cols];
        
        for (int row = 0; row < rows; row ++)
        {
            for (int col = 0; col < cols; col ++)
                twoDArray[row][col] =  (row + 1) * (col + 1);
        }
                
        System.out.println("Display values using values[row][col]");
        for (int row = 0; row < rows; row ++)
        {
            for (int col = 0; col < cols; col ++)
                System.out.print(twoDArray[row][col] + " ");
        
            System.out.println();
        }

        System.out.println("Display values using the enhanced for loop for each row");
        for (int row = 0; row < rows; row ++)
        {
            for (int num: twoDArray[row])
                System.out.print(num + " ");
        
            System.out.println();
        }

        System.out.println("Display values using two enhanced for loops");
        for (int[] row: twoDArray)
        {
            for (int num: row)
                System.out.print(num + " ");
        
            System.out.println();
        }
        
        System.out.println("Display values using a enhanced for loop with Arrays.toString");
        for (int[] row: twoDArray)
        {
            System.out.println(Arrays.toString(row));
        }

        System.out.print("Enter a row index: ");
        int rowIndex = in.nextInt();
        int max = Integer.MIN_VALUE;
        for (int col = 0; col < cols; col ++)
        {
            int num = twoDArray[rowIndex][col];
            if (num > max)
                max = num;
        }
        System.out.printf("The largest value of row %d is %d.%n", rowIndex, max);
        
        max = Integer.MIN_VALUE;
        for (int num: twoDArray[rowIndex])
        {
            if (num > max)
                max = num;
        }
        System.out.printf("The largest value of row %d is %d.%n", rowIndex, max);

        System.out.print("Enter a column index: ");
        int colIndex = in.nextInt();
        max = Integer.MIN_VALUE;
        for (int row = 0; row < rows; row ++)
        {
            int num = twoDArray[row][colIndex];
            if (num > max)
                max = num;
        }
        System.out.printf("The largest value of column %d is %d.%n", colIndex, max);
    }
}
