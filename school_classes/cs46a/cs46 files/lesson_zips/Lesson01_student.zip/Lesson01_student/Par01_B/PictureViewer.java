// Keep the step instructions and add your code below them.
/**
 * Load and draw a picture.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class PictureViewer
{
    public static void main(String[] args)
    {
        // Step 2: Create a picture object pic and load
        //         picture "dogcat.png"


        // Step 3: Draw the picture

        
        // Step 4: Display the (x, y) coordnates of the picture
        System.out.println("X-coordinate: " + 
        System.out.println("Y-coordinate: " + 

        // Step 5: Display the size of the picture
        System.out.println("Width : " + 
        System.out.println("Height: " + 
    }
}
