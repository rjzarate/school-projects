// Step 1: Import the Scanner class for input

/**
 * A Java program to computer the double average of three integers.
 * 
 * Step 2: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class AverageOfThreeIntegers
{
    public static void main(String[] args)
    {
        final int COUNT_OF_NUMBERS = 3;
        
        // Step 3: Declare an int variable sum with an initial value of zero


        // Step 4: Declare a Scanner object to read input from the keyboard
        
        
        // Step 5: Display an input prompt "Enter the first integer: "
        
        
        // Step 6: Read in an integer and store it in an int variable intNum
        

        // Step 7: Add the input integer to sum
        
        
        // Step 8: Display an input prompt "Enter the second integer: "
        

        // Step 9: Read in an integer and store it in intNum
        

        // Step 10: Add the input integer to sum
        
        
        // Step 11: Display an input prompt "Enter the third integer: "
        
        
        // Step 12: Read in an integer and store it in intNum
        

        // Step 13: Add the input integer to sum
        
        
        // Step 14: display the integer sum of the three integers
        // Sample output assuming the sum is 10
        //     "The sum of the three integers is 10."
        
       
        // Step 15: Compute and display the double average of the three integers
        // Sample output assuming the average is 3.3333333333333335
        //     "The average of the three integers is 3.3333333333333335."
        
    }
}
