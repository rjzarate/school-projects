// Step 1: Import the Scanner class for input

/**
 * A Java program to calculate the circumference, area,
 * surface area, and volume based on an input radius.
 * 
 * Step 2: Enter your name for @author and today's date for @version
 * @author  
 * @version 
   */
public class CircleAndSphere
{
    public static void main(String[] args)
    {
        // Step 3: Create a Scanner object to read input from the keyboard
        

        // Step 4: Display a prompt "Enter the radius: "
        //         and stay on the same line
        
        
        // Step 5: Read a double number for radius and 
        //         store it in a variable
        

        // Step 6: Calculate the circumference using the input radius
        //         and store it in a variable
        

        // Step 7: Calculate the area using the input radius
        //         and store it in a variable
        

        // Step 8: Calculate the surface area using the input radius
        //         and store it in a variable
        
        
        // Step 9: Calculate the volume using the input radius
        //         and store it in a variable
        
        
        // Step 10: Display the radius and calculated values
        // Sample output for radius 5
        // The radius: 5.0
        // The circle circumference: 31.41592653589793
        // The circle area: 78.53981633974483
        // The sphere surface area: 314.1592653589793
        // The sphere volume: 523.5987755982989

    }
}
