import java.util.Arrays;
import java.util.Scanner;
/**
 * Working with Java int arrays.
 *
 * @author  Qi Yang
 * @version 2022-10-27
 */
public class IntArray
{
    public static void main(String[] args)
    {
        int[] intArray = {5, 7, 9, 11, 13};
       
        System.out.println(intArray.length);
        // Output: 5
        
        for (int i = 0; i < intArray.length; i ++)
            System.out.print(intArray[i] + " ");
        // Output: 5 7 9 11 13
        
        System.out.println();
        
        for (int num: intArray)
            System.out.print(num + " ");
        // Output: 5 7 9 11 13

        System.out.println();

        System.out.println(Arrays.toString(intArray));
        // Output: [5, 7, 9, 11, 13]

        
        // Constructing an array with the count 
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the count of integers: ");
        int count = in.nextInt();   // 5
        int[] intArray2 = new int[count];
        
        // Generating array element values
        for (int i = 0; i < count; i ++)
        {
            intArray2[i] = 2 * i + 5;;
        }
        
        System.out.println(Arrays.toString(intArray2));
        // Output: [5, 7, 9, 11, 13]
        
        // Input array element values
        for (int i = 0; i < count; i ++)
        {
            System.out.print("Enter an integer: ");
            intArray2[i] = in.nextInt();
        }
        // input: 5 7 9 11 13

        for (int i = 0; i < intArray2.length; i ++)
            System.out.print(intArray2[i] + " ");
        // Output: 5 7 9 11 13
        
        System.out.println();

        for (int num: intArray2)
            System.out.print(num + " ");
        // Output: 5 7 9 11 13

        System.out.println();
                
        System.out.println(Arrays.toString(intArray));
        // Output: [5, 7, 9, 11, 13]

        // output the first element
        System.out.println(intArray2[0]);  	
         
        // increment the 2nd element
        intArray2[1] ++;
        
        // swap the two elements at index 3 and 4
        int temp = intArray2[3];
        intArray2[3] = intArray2[4];
        intArray2[4] = temp;
        
        System.out.println(Arrays.toString(intArray2));
        // Output: [5, 8, 9, 13, 11]
    
        
        // Constricting an array without a known count 
        final int MAX_SIZE = 200;
        int[] intArray3 = new int[MAX_SIZE]; 
        int currentSize = 0;

        // Input array element values to a partial array
        // and update currentSize
        System.out.print("Enter an integer, Q to stop: ");
        while (in.hasNextInt() && currentSize < MAX_SIZE)
        {
            intArray3[currentSize] = in.nextInt();
            currentSize ++;
            
            System.out.print("Enter an integer, Q to stop: ");
        }
        
        // Read the sentinel Q
        String input = in.next();
        
        System.out.println("currentSize: " + currentSize);
        System.out.println("length: " + intArray3.length);

        System.out.println(Arrays.toString(intArray3));

        for (int i = 0; i < currentSize; i ++)
            System.out.print(intArray3[i] + " ");
        System.out.println();

        // Adding a value at the end of the array
        System.out.print("Enter an integer: ");
        int num = in.nextInt();  
        intArray3[currentSize] = num;
        //intArray3[currentSize] = in.nextInt();
        
        currentSize ++;

        // Input a value to replace an array element
        System.out.print("Enter an integer: ");
        num = in.nextInt(); 
        
        // Replacing the first element
        intArray3[0] = num;
                
        for (int i = 0; i < currentSize; i ++)
            System.out.print(intArray3[i] + " ");
        System.out.println();
    
        // Finding the smallest value in the array
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < currentSize; i ++)
        {
            if (intArray3[i] < min)
                min = intArray3[i];
        }
        System.out.printf("Smallest value: %d%n", min);
    
        // Do not use length for partial array
        min = Integer.MAX_VALUE;
        for (int i = 0; i < intArray3.length; i ++)
        {
            if (intArray3[i] < min)
                min = intArray3[i];
        }
        System.out.printf("Smallest value: %d%n", min);
    }
}
