/**
 * Swappping two integers.
 *
 * @author  Qi Yang
 * @version 2022-10-20
 */
public class SwapTwoIntegers
{
    public static void main(String[] args)
    {
        int x = 5, y = 7;
        System.out.printf("x: %d, y: %d\n", x, y);

        x = y;
        y = x;
        System.out.printf("x: %d, y: %d\n", x, y);

      
        x = 5;
        y = 7;
        int temp = x;
        x = y;
        y = temp;
        System.out.printf("x: %d, y: %d\n", x, y);
      
    }
}
