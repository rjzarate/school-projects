import java.util.ArrayList;
/**
 * Working with array lists.
 *
 * @author  Qi Yang
 * @version 2022-10-20
 */
public class Names
{
    public static void main(String[] args)
    {
        ArrayList<String> names;

        names = new ArrayList<String>();
        
        int count = names.size();
        System.out.printf("Number of elements: %d.%n", 
                           count);
                           
        names.add("Horstmann");     // at index 0
        names.add("O'Brein");       // at index 1
        
        names.add(0, "Clifton");    // at index 0
        System.out.println(names.toString());
        // Output: [Clifton, Horstmann, O'Brein]
        
        names.add(1, "Yang");       // at index 1
        System.out.println(names);  // toString()
        // Output: [Clifton, Yang, Horstmann, O'Brein]
        
        System.out.println(names.size());
        // Output: 4
        
        names.set(1, "Kim");
        System.out.println(names.toString());
        // Output: [Clifton, Kim, Horstmann, O'Brein]
        
        names.set(3, "Yang");
        System.out.println(names.toString());
        // Output: [Clifton, Kim, Horstmann, Yang]
        
        String name = names.remove(1);
        System.out.println(names.toString());
        // Output: [Clifton, Horstmann, Yang]
        System.out.println(name);
        // Output: Kim
              
        String kim = "Kim";
        names.add(0, kim);
        System.out.println(names.toString());
        // Output: [Kim, Clifton, Horstmann, Yang]
        
        name = "Kim";
        boolean removed = names.remove(name);
        //boolean removed = names.remove("Kim");
        System.out.println(names.toString());
        // Output: [Clifton, Horstmann, Yang]
        System.out.println(removed);
        // Output: true
        
        removed = names.remove("Kim");
        System.out.println(names.toString());
        // Output: [Clifton, Horstmann, Yang]
        System.out.println(removed);
        // Output: false
        
        names.add("Kim");
        System.out.println(names.toString());
        // Output: [Clifton, Horstmann, Yang, Kim]
        
        name = names.get(0);     
        System.out.println(names.toString());
        // Output: [Clifton, Horstmann, Yang, Kim]
        
        System.out.println(name);
        // Output: Clifton
    
        count = names.size();
        System.out.println(count);
        // Output: 4
        
        name = names.get(count - 1);	
        System.out.println(name);     
        // Output: Kim
        
        name = names.get(count - 2); 
        System.out.println(name);
        // Output: Yang
        
        String temp = names.get(0);
        names.set(0, names.get(1));
        names.set(1, temp);
        
        System.out.println(names.toString());
        // Output: [Horstmann, Clifton, Yang, Kim]
        
        for (int i = 0; i < names.size(); i ++)
        {
            name = names.get(i);
            System.out.println(name);
        }
        
        for (int i = 0; i < names.size(); i ++)
            System.out.println(names.get(i));
        
        for (String aName: names)
            System.out.println(aName);
    }
}
