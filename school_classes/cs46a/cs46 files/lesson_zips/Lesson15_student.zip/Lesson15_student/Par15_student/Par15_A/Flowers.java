// Step 1: Import Java ArrayList class

/**
 * Create an array list of string and call several methods
 * on the array list.
 *
 * Step 2: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class Flowers
{
    public static void main(String[] args)
    {
        // Step 3: Create an array list of String called garden

        
        // Step 4: Print the array list

        
        // Step 5: Add "rose", "daisy", and "violet" in that order


        // Step 6: Print the array list


        // Step 7: Add "petunia" at index 0


        // Step 8: Add  "pansy" at index 2


        // Step 9: Print the array list

        
        // Step 10: Replace the element at index 2 with "marigold"


        // Step 11: Replace the last element with "zinnia"


        // Step 12: Print the array list


        // Step 13: Remove the second element and store the
        //          removed element in a variable flower


        // Step 14: Print the removed element on one line


        // Step 15: Print the array list

    }
}
