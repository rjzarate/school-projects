import java.util.Scanner;
/**
 * The Java program converts letter grades to numeric grades.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class ConvertingGrades
{
    public static void main(String[] args)
    {
        final double NUMERIC_GRADE_A = 4.0;
        final double NUMERIC_GRADE_B = 3.0;
        final double NUMERIC_GRADE_C = 2.0;
        final double NUMERIC_GRADE_D = 1.0;
        final double NUMERIC_GRADE_F = 0.0;
        final double INVALID_GRADE = -1.0;
        
        // Step 2: Create a Scanner object to read input
        //         from the key board
        
        
        // Step 3: Display an input prompt 
        //         "Enter the letter grade: " 
        

        // Step 4: Read in a single string and assign
        //         it to a string variable gradeStr
        
        
        // Step 5: Convert all chars of gradeStr to upper case
        
        
        // Step 6: Get the first char of gradeStr
        //         and assign it to a char variable grade
        
        
        double numGrade = 0;

        // Step 7: Use one if statement with multiple alternatives
        //         to calculate the numeric grade according to the 
        //         following table:
        //          Letter Grade        Numeric Grade
        //              A                   4.0
        //              B                   3.0
        //              C                   2.0
        //              D                   1.0
        //              F                   0.0
        //         Others (errors)         -1.0
        // You can use 'A', 'B', 'C', 'D', and 'F' in your code
        // but you cannot use any magic numbers, even 0.0 or -1.0.


        // Step 8: Display the numeric grade with one decimal digit
        //         and the letter grade within single quotes
        // Sample output
        // The numeric grade for letter grade 'B' is 3.0.

    }
}
