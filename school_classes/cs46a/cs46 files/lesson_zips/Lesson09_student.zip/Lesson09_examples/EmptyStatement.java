import java.util.Scanner;
/**
 * If statements examples.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class EmptyStatement
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
           
        System.out.print("Enter an integer: ");
        int num = in.nextInt();
        
        if (num > 0);
            System.out.println("Positive!");
        
        System.out.println(num);
    }
}
