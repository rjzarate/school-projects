import java.util.Scanner;
/**
 * Use if statements on strings and chars.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class CharAndString
{
    public static void main(String[] args)
    {
        final char UPPER_A = 'A'; 

        Scanner in = new Scanner(System.in);

        System.out.print("Enter a string: ");   // April (Java)
        String str1 = in.next();
        
        char aChar = str1.charAt(0); 
    
        if (aChar == UPPER_A)
            System.out.println("It's an A!");
        else 
            System.out.println("It's not an A!");

        System.out.print("Enter another string: ");
        String str2 = in.next();  // input: Java
        
        if (str1 == str2) 
            System.out.println("Same string!");
        else
            System.out.println("Different strings!");
            
        if (str1.equals(str2)) 
            System.out.println("Same string!");
        else
            System.out.println("Different strings!"); 
    }
}
