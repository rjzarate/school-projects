import java.util.Scanner;
/**
 * Use if statements to convert scores to grades.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class ScoreToGrade
{
    public static final int A_SCORE = 90;
    public static final int B_SCORE = 80;
    public static final int C_SCORE = 70;
    public static final int D_SCORE = 60;
    
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a score: ");
        int score = in.nextInt();
        
        char grade;
        if (score >= 90)
           grade = 'A';
        else if (score >= 80)
           grade = 'B'; 
        else if (score >= 70)
           grade = 'C'; 
        else if (score >= 60)
           grade = 'D';
        else 
           grade = 'F'; 

        System.out.printf("The grade for score %d is '%s'.\n",
                   score, grade);

        if (score >= A_SCORE)
           grade = 'A';
        else if (score >= B_SCORE)
           grade = 'B'; 
        else if (score >= C_SCORE)
           grade = 'C'; 
        else if (score >= D_SCORE)
           grade = 'D';
        else 
           grade = 'F'; 
           
        System.out.printf("The grade for score %d is '%s'.\n",
                   score, grade);
              
        // DO NOT use independent if statements
        if (score >= 90)
           grade = 'A';
        if (score < 90 && score >= 80)
           grade = 'B'; 
        if (score < 80 && score >= 70)
           grade = 'C'; 
        if (score < 70 && score >= 60)
           grade = 'D';
        if (score < 60) 
           grade = 'F'; 
                   
        System.out.printf("The grade for score %d is '%s'.\n",
                   score, grade);
    }
}
