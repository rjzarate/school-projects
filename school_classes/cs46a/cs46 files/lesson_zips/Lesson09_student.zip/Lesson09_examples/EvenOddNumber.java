import java.util.Scanner;
/**
 * If statements examples.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class EvenOddNumber
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
           
        System.out.print("Enter an integer: ");
        int num = in.nextInt();

        if (num % 2 == 0)
            System.out.printf("%d is an even number.\n", num);
        else 
            System.out.printf("%d is an odd number.%n", num);

        
        final int EVEN_NUMBER_DIVISOR = 2; 
        
        if ((num % EVEN_NUMBER_DIVISOR) == 0)
            System.out.printf("%d is an even number.\n", num); 
        else 
            System.out.printf("%d is an odd number.\n", num); 
    }
}
