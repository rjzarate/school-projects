import java.util.Scanner;
/**
 * If statements examples.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class DivideByZero
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int quotient;
        
        System.out.print("Enter two integers: ");
        int num1 = in.nextInt();
        int num2 = in.nextInt();

        quotient = num1 / num2;
        System.out.println(quotient);

    }
}
