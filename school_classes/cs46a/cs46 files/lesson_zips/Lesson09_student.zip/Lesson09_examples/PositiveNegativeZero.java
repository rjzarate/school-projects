import java.util.Scanner;
/**
 * If statements examples.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class PositiveNegativeZero
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
           
        System.out.print("Enter an integer: ");
        int num = in.nextInt();
        
        if (num > 0)
            System.out.println("Positive!");
        else
            System.out.println("Negative!");
            
        if (num > 0)
            System.out.println("Positive!");
        else if (num < 0)
            System.out.println("Negative!");
        else
            System.out.println("Zero!");
        
    }
}
