/**
 * If statements examples.
 *
 * @author  Qi Yang
 * @version 2022-09-22
 */
public class StatementBlock
{
    public static void main(String[] args)
    {
        int num1 = 3;
        int num2 = 0;

        int quotient = 0;
        if (num2 == 0) 
            System.out.println("num2 is zero!");
        else
            quotient = num1 / num2;
            System.out.println(quotient);
            
  
        if (num2 == 0) 
            System.out.println("num2 is zero!");
        else
        {
            quotient = num1 / num2;
            System.out.println(quotient);
        }

        if (num2 == 0)
        {
            System.out.println("num2 is zero!");
        }
        else
        {
            quotient = num1 / num2;
            System.out.println(quotient);
        }
        
        if (num2 != 0)
        {
            quotient = num1 / num2;
            System.out.println(quotient);
        }
        else
        {
            System.out.println("num2 is zero!");
        }
    }
}
