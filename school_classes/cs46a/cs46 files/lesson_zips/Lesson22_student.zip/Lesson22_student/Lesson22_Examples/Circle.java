/**
 * The class models objects of circles. 
 * 
 * @author  Qi Yang
 * @version 2022-11-22
 */ 
public class Circle implements Measurable
{
    private double radius;
    private int x, y; 

    /**
     * Creates a circle with a specified radius at 
     * a specified position (x, y).
     * 
     * @param x the x coordinate of this circle
     * @param y the y coordinate of this circle
     * @param radius the radius of this circle
     */
    public Circle(int x, int y, double radius)
    {
        this.radius = radius;
        this.x = x;
        this.y = y;
    }
    
    /**
     * Gets the x coordinate of the center of this circle.
     * 
     * @return the x coordinate of this circle
     */
    public int getX()
    {
        return x;
    }
    
    /**
     * Gets the y coordinate of the center of this circle.
     * 
     * @return the y coordinate of this circle
     */
    public int getY()
    {
        return y;
    }
    
    /**
     * Gets the area of this circle.
     * 
     * @return the area of this circle
     */
    public double area()
    {
        return radius * radius * Math.PI;
    }
    
    /**
     * Builds a string to represent this circle.
     * 
     * @return a string in the format "Circle[radius=10.50,x=5,y=10]"
     */
    public String toString()
    {
        String s = "Circle[radius=" + radius + ",x=" + x + ",y=" + y +"]";
        return s;
    }

    /**
     * Implements the getMeasure() method.
     * 
     * @return the area of this circle
     */
    public double getMeasure()
    {
        return area();
    }
}
