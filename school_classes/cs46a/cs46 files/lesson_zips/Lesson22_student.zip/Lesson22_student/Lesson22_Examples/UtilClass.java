import java.util.ArrayList;
/**
 * A utility class.
 *
 * @author  Qi Yang
 * @version 2022-11-22
 */
public class UtilClass
{
    /**
     * Gets the max value from all objects in an array of Measurable.
     * 
     * @param theArray the array of Measurable
     * @param count the number of Measurable objects in the array
     * @return the max value from all Measurable objects in the array
     *         Double.MIN_VALUE if the array is empty
     */
    public static double max(Measurable[] theArray, int count)
    {
        double max = Double.MIN_VALUE;

        for (int i = 0; i < count; i ++)
        {
            double value = theArray[i].getMeasure(); 
            if (value > max)
                max = value;
        }
        
        return max;
    }
}
