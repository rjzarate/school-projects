/**
 * Models bank account objects.
 *
 * @author  Qi Yang
 * @version 2022-11-22
 */
public class BankAccount implements Measurable
{
    private static int lastAssignedNumber = 1000;
    
    private int accountNumber;
    private double balance;

    /**
     * Constructs an object of bank account with amount
     * as the initial balance.
     * 
     * @param amount the initial balance of this bank account
     */
    public BankAccount(double amount)
    {
        lastAssignedNumber ++;
        accountNumber = lastAssignedNumber;
        balance = amount;
    }
    
    /**
     * Gets the balance of this bank account.
     *
     * @return the balance of this bank account
     */
    public double getBalance()
    {
        return balance;
    }

    /**
     * Implements the getMeasure() method.
     * 
     * @return the balance of this bank account
     */
    public double getMeasure()
    {
        return balance;
    }
}
