import java.util.*;
/**
 * A tester program for class UtilClass.
 *
 * @author  Qi Yang
 * @version 2022-11-22
 */
public class UtilClassTester
{
    public static final int MAX_SIZE = 100;

    public static void main(String[] params)
    {
        Random generator = new Random(2020);
        int count;
        double max;
        
        Circle[] allCircles = new Circle[MAX_SIZE];
        count = 20;
        for (int i = 0; i < count; i ++)
        {
            int x = generator.nextInt(11);
            int y = generator.nextInt(11);
            double radius = generator.nextInt(11) + 10;
            allCircles[i] = new Circle(x, y, radius);
            
            System.out.printf("%.3f\n", allCircles[i].area());        
        }
         
        max = UtilClass.max(allCircles, count);
        System.out.printf("Max area of all circles: %.3f.\n", max);
        System.out.println("Expected: 1256.637");        

        BankAccount[] allAccounts = new BankAccount[MAX_SIZE];
        count = 50;
        for (int i = 0; i < count; i ++)
        {
            allAccounts[i] = new BankAccount(generator.nextInt(500) + 1);
            System.out.printf("%.2f\n", allAccounts[i].getBalance());        
        }
        
        max = UtilClass.max(allAccounts, count);
        System.out.printf("Max balance of all accounts: %.2f.\n", max);
        System.out.println("Expected: 493.00");        

        Student[] allStudents = new Student[MAX_SIZE];
        count = 5;
        
        allStudents[0] = new Student("John", 3.5);
        allStudents[1] = new Student("Tom", 3.05);
        allStudents[2] = new Student("Mike", 2.95);
        allStudents[3] = new Student("Joe", 2.5);
        allStudents[4] = new Student("Mary", 3.25);

        max = UtilClass.max(allStudents, count);
        System.out.printf("Max GPA of all students: %.2f.\n", max);
        System.out.println("Expected: 3.50"); 
   }
}
