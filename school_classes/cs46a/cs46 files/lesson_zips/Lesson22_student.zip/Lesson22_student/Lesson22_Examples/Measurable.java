/**
 * An interface with one method to return a double value.
 *
 * @author  Qi Yang
 * @version 2022-11-22
 */
public interface Measurable
{
    /**
     * Gets a measurable double value from this object.
     *
     * @return the measurable double value from this object
     */
    double getMeasure();
}
