/**
 * The class models students with name and gpa.
 * 
 * @author  Qi Yang
 * @version 2022-11-22
 */
public class Student implements Measurable
{
    private String id;
    private double gpa;

    /**
     * Constructs a Student object.
     * 
     * @param id the id of this student
     * @param gpa the gpa of this student
     */
    public Student(String id, double gpa)
    {
        this.id = id;
        this.gpa = gpa;
    }

    /**
     * Gets the id of this student.
     * 
     * @return the id of this student
     */
    public String getId()
    {
       return id;
    }
    
    /**
     * Gets the gpa of this student.
     * 
     * @return the gpa of this student
     */
    public double getGpa()
    {
        return gpa;
    }
    
    /**
     * Implements the getMeasure() method.
     * 
     * @return the gpa of this student
     */
    public double getMeasure()
    {
        return gpa;
    }
}