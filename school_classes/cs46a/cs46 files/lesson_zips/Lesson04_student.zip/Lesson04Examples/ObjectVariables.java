/**
 * Lesson04 examples.
 *
 * @author  Qi Yang
 * @version 2022-09-06
 */
public class ObjectVariables
{
    public static void main(String[] args)
    {
        Day examOne = new Day(2022, 10, 6);
        System.out.println(examOne);

        Day exam = examOne;
        
        exam.addDays(2);
        
        System.out.println(examOne);
    }
}
