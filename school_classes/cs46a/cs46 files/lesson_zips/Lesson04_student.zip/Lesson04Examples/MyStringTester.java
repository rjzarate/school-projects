/**
 * Testing String methods.
 *
 * @author  Qi Yang
 * @version 2022-09-06
 */
public class MyStringTester
{
    public static void main(String[] args)
    {
        String course = new String("CS 46A");
        String language = "Java";

        System.out.println(language.length());
       
        System.out.println(language);
        System.out.println(language.toUpperCase());
        
        System.out.println(language);
        
        String str = language.toUpperCase();
        System.out.println(str);
        
        System.out.println(language);

        language = language.toUpperCase();
        System.out.println(language);
        
        System.out.println(course.replace('A', 'B'));
        System.out.println("Expected: CS 46B"); 
                
        System.out.println(course.replace(" ", ""));
        System.out.println("Expected: CS46A"); 

        System.out.println(course.replace("CS", "SE"));
        System.out.println("Expected: SE 46A");

        String today = "2022-09-06";
        System.out.println(today);

        System.out.println(today.replace('2', 't'));
        System.out.println("Expected: t0tt-09-06"); 

        char ch = course.charAt(0);
        System.out.println(ch);
        System.out.println("Expected:  C");
        
        System.out.println(course.charAt(1));
        System.out.println("Expected: S");
        
        System.out.println(course.charAt(5));
        System.out.println("Expected: A");

        String title = "Introduction to Programming";

        int index = title.length() - 1;
        
        System.out.println(title.charAt(index));
        System.out.println("Expected: g");
        
        index = title.length();
        // Run time error!
        System.out.println(title.charAt(index));
    }
}
