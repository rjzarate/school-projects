// Step 1: Import class ArrayList and Collections

/**
 * Manages an array list of class Frog.
 *
 * Step 2: Enter your name for @author and the password for @version
 * @author  
 * @version 
 */
public class ArrayListFrog
{
    // Step 3: Declare an instance variable for
    //         the array list to be managed
    
    
    // Step 4: Complete the first constructor
    /**
     * Constructs an ArrayListFrog object by initializing
     * the instance variable to the passed in array list.
     * 
     * @param list the array list of class Frog
     *        to be managed
     */
    public ArrayListFrog(ArrayList<Frog> list)
    {
        
    }

    // Step 5: Complete the second constructor
    /**
     * Constructs an ArrayListFrog object by creating
     * a new empty array list of class Frog.
     */
    public ArrayListFrog()
    {
        
    }

    // Step 6: Complete method add()
    /**
     * Adds a frog to the array list at a specified 
     * position if the specified index is valid and 
     * does nothing otherwise.
     *
     * @param index the specified position to add 
     * @param frog the frog to be added
     */
    public void add(int index, Frog frog)
    {

    }
    
    // Step 7: Complete method delete()
    /**
     * Deletes and returns the frog at the specified position
     * if index is valid and does nothing otherwise.
     * 
     * @param index the index of the frog to be deleted 
     *        from the array list
     * @return the frog deleted if index is valid
     *         null if the index is invalid
     */
    public Frog delete(int index)
    {

    }
    
    // Step 8: Complete method swap()
    /**
     * Swaps two frogs at specified positions in the array
     * list if both index1 and index2 are valid and does
     * nothing otherwise.
     * 
     * Use only one temporary variable.
     * 
     * @param index1 the index of the first frog to be swapped
     * @param index2 the index of the second frog to be swapped
     */
    public void swap(int index1, int index2)
    {

    }

    // Step 9: Override method toString()
    /**
     * Gets a string representation for the array list.
     * 
     * @return the string returned by the toString() method
     *         on the array list
     */
    @Override
    public String toString()
    {

    }

    // Step 10: Complete method firstInTheRange()
    /**
     * Gets the first frog in the array list whose weight 
     * is in the range of [lowLimit, highLimit].
     * 
     * You should use the enhanced for loop.
     * You should call method Double.compare() to compare the weights.
     * 
     * @param lowLimit the low limit of the specified range
     * @param highLimit the high limit of the specified range
     * @return the first frog whose weight is in the specified range
     *         null if no such frog in the array list
     */
    public Frog firstInTheRange(double lowLimit, double highLimit)
    {

    }
    
    // Step 11: Complete method sort()
    /**
     * Calls a static method to sort the array list.
     */
    public void sort()
    {

    }
}