import java.util.Scanner;
/**
 * The Java program tries to read a positive integer
 * and stays in a loop if the input is invalid; then
 * uses nested for loops to draw a triangle of the 
 * specified size.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class DrawingATriangle
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        // Step 2: Asking for a positive integer using prompt 
        //              "Enter a positive integer: "
        //         Read the input and save it in an int variable size 


        // Step 3: While size is not positive
        //             Display a message with the integer 
        //                  sample message assuming the input is -3
        //                  "Not a positive integer: 3"
        //             Asking for a positive integer using the same prompt 
        //             Read the input and save it in size

        
        // Step 4: Use nested for loops to draw a triangle
        // Sample output (assuming the input size is 5)
        // *
        // **
        // ***
        // ****
        // *****

        
    }
}
