import java.util.Random;
/**
 * Generate random numbers with and without seeds.
 *
 * @author  Qi Yang
 * @version 2022-10-18
 */
public class RandomNumbers
{
    public static void main(String[] args)
    {
        Random generator = new Random();

        for (int i = 0; i < 20; i ++)
            System.out.printf("%3d", generator.nextInt(15));

        System.out.println();
       
        for (int i = 0; i < 20; i ++)
            System.out.printf("%3d", generator.nextInt(15) + 11);

    }
}
