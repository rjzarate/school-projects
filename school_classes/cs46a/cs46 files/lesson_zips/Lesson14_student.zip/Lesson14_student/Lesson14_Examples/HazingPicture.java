import java.util.Scanner;
/**
 * A Java program to draw a 2-D grid based on 
 * input number of rows and number of columns.
 *
 * @author  Qi Yang
 * @version 2022-10-18
 */
public class HazingPicture
{
    public static void main(String[] args)
    {
        Picture pic = new Picture("oliver_bed.jpg"); 
        pic.draw();        
                
        int rows = pic.getHeight();
        int cols = pic.getWidth();
        
        for (int y = 0; y < rows; y += 2)
            for (int x = 0; x < cols; x++)
                pic.setColorAt(x, y, Color.WHITE);
                
        pic.draw();        
    }
}
