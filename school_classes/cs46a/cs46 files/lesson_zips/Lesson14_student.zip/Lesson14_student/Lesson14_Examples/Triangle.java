import java.util.Scanner;
/**
 * A Java program to draw a 2-D grid based on 
 * input number of rows and number of columns.
 *
 * @author  Qi Yang
 * @version 2022-10-18
 */
public class Triangle
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
                
        System.out.print("Enter the size of a triangle ");
        int size = in.nextInt();
        
        for (int row = 1; row <= size; row ++)
        {
            for (int col = 1; col <= row; col ++)
                System.out.print("*");
        
            System.out.println();
        }

    }
}
