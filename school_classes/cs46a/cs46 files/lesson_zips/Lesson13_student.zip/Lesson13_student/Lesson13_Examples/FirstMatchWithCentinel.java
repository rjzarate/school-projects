import java.util.Scanner;
/**
 * Read a set of integer scores ending with a Q and
 * find if a target score is in the set of scores.
 * Sample input (input ends with a Q)
 * 40  50  0  35  49  50  Q
 *
 * @author  Qi Yang
 * @version 2022-10-13
 */
public class FirstMatchWithCentinel
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter the target score: ");
        int target = in.nextInt();

        boolean found = false;
        System.out.print("Enter a score: ");
        while (!found && in.hasNextInt())
        {
            int score = in.nextInt();
                    
            if (score == target)
                found = true;
            else
                System.out.print("Enter a score: ");
        }
                
        System.out.printf("Some one has score %d: %s.%n", target, found);
    }
}
