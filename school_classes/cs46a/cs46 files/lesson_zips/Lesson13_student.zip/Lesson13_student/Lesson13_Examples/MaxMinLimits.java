import java.util.Scanner;
/**
 * Read a set of scores and find the highest and lowest scores,
 * initializing max to LOW_LIMIT and min to HIGH_LIMIT.
 * Sample input (the first is the count)
 * 6  40  50  0  35  49  50
 *
 * @author  Qi Yang
 * @version 2022-10-13
 */
public class MaxMinLimits
{
    public static final int LOW_LIMIT = 0;
    public static final int HIGH_LIMIT = 50;
    
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        int min = HIGH_LIMIT;
        int max = LOW_LIMIT;
        
        System.out.print("Enter the number of scores: ");
        int count = in.nextInt();
        
        for (int i = 0; i < count; i ++)
        {
            System.out.print("Enter a score: ");
            int score = in.nextInt();
            if (score < min)
                min = score; 
            if (score > max)
                max = score; 
        }
        
        System.out.printf("The highest score is %d.%n", max);
        System.out.printf("The lowest score is %d.%n", min);
        
        System.out.println(Double.MAX_VALUE);
        System.out.println(Double.MIN_VALUE);
        System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);
    }
}
