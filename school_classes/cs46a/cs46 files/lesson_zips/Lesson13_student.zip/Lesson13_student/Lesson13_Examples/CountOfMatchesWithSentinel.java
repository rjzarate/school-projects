import java.util.Scanner;
/**
 * Read a set of integer scores ending with a Q
 * and find the count of a target score.
 * Sample input 
 * 40  50  0  35  49  50  Q
 *
 * @author  Qi Yang
 * @version 2022-10-13
 */
public class CountOfMatchesWithSentinel
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter the target score: ");
        int target = in.nextInt();

        int countOfTarget = 0;
        System.out.print("Enter a score: ");
        while (in.hasNextInt())
        {
            int score = in.nextInt();
                    
            if (score == target)
                countOfTarget ++;
            
            System.out.print("Enter a score: ");
        }
        
        System.out.printf("Count of target %d: %d.%n", 
                           target, countOfTarget);
    }
}
