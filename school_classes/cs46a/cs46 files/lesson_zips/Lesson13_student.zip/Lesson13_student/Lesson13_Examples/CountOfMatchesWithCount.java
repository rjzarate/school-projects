import java.util.Scanner;
/**
 * Read a set of integer scores beginning with the
 * count and find the count of a target score.
 * Sample input (the first value if the count)
 * 6  40  50  0  35  49  50
 *
 * @author  Qi Yang
 * @version 2022-10-13
 */
public class CountOfMatchesWithCount
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter the target score: ");
        int target = in.nextInt();

        System.out.print("Enter the number of scores: ");
        int count = in.nextInt();
        int countOfTarget = 0;
        for (int i = 0; i < count; i ++)
        {
            System.out.print("Enter a score: ");
            int score = in.nextInt();
                    
            if (score == target)
                countOfTarget ++;
        }
        
        System.out.printf("Count of target %d: %d.%n", 
                           target, countOfTarget);
    }
}
