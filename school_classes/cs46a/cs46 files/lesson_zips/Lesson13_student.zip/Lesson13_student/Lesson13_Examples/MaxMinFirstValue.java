import java.util.Scanner;
/**
 * Read a set of scores and find the highest and lowest 
 * scores, initializing both to the first score.
 * Sample input 
 * 40  50  0  35  49  50  Q
 *
 * @author  Qi Yang
 * @version 2022-10-13
 */
public class MaxMinFirstValue
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter the first score: ");
        int max = in.nextInt();
        int min = max;
        
        System.out.print("Enter next score or Q to quit: ");
        while(in.hasNextInt())
        {
            int score = in.nextInt();
        
            if (score > max)
                max = score;
            else if (score < min)
                min = score; 
        
            System.out.print("Enter next score or Q to quit: ");
        }
        
        System.out.printf("The highest score is %d.%n", max);
        System.out.printf("The lowest score is %d.%n", min);
    }
}
