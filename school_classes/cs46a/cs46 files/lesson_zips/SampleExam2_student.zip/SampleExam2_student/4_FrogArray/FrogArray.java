/**
 * Manages a partial array of class Frog.
 *
 * Step 1: Enter your name for @author and the password for @version
 * @author  
 * @version 
 */
public class FrogArray
{
    // Step 2: Declare two instance variables to 
    //         manage a partial array of class Frog
    

    // Step 3: Write the constructor according to the comment
    //         including possible Javadoc tags
    /**
     * The constructor has two parameters for the two
     * instance variables:
     *      array: an array of Frog
     *      count: the number of frogs in array
     * 
     */


    // Step 4: Write method add() according to the comment
    //         including possible Javadoc tags
    /**
     * The method has one parameter of class Frog. If the 
     * array is not full, the method will add the frog at 
     * the end of the array and update the number of frogs 
     * in the array; otherwise, it will not do nothing.
     *
     */

    
    // Step 5: Write method delete() according to the comment
    //         including possible Javadoc tags
    /**
     * The method has one parameter for the index of a frog to
     * be deleted from the array. If the index is valid, the
     * method will remove the frog from the array, shifting 
     * all subsequent elements to the left by one position, 
     * and return the frog. Otherwise, the method will not
     * change the aray at all and return null.
     * 
     */

    
    // Step 6: Write method lastOutOfRange() according to the comment
    //         including possible Javadoc tags
    /**
     * The method has two int parameters for the low and high
     * limits and will return the last frog in the array whose
     * weight is not in the specified range (smaller than the 
     * low limit or larger than the high limit). The method 
     * will return null if no frog is out of the range.
     * 
     */

    
    // Step 7: Override method toString() according to the comment
    //         including possible Javadoc tags
    /**
     * The method has no parameters and will return a string 
     * in the following format:
     *         [Frog[...], Frog[...], ..., Frog[...]]
     * where each Frog[...] is the string returned by method
     * toString() on a frog in the array.
     * 
     * Do not use an if statement inside the loop.
     * 
     */


}