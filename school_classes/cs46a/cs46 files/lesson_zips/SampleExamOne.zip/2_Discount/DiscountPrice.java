// Step 1: import Java class Scanner

/**
 * Ask the user for product name, its original price,
 * and the discount rate, then calculate and display
 * the discount price for the product.
 *
 * Step 2: Enter your name for @author and the password for @version
 * @author  
 * @version 
 */
public class DiscountPrice
{
    public static void main(String[] args)
    {
        // Step 3: Create a Scanner object to get
        //         input from the keyboard


        // Step 4: Ask for the product name using prompt 
        //                 "Enter the product name: " 
        //         Read in the product name and store it in a
        //            variable after removing spaces from both ends
        //         Note: The product name could have multiple words
        //               such as "iPad Pro"

        
        // Step 5: Ask for the original price using prompt
        //                 "Enter the original price: "
        //         If the next input token is not a double number
        //            Read in the input
        //            Display a message on one line 
        //                   Sample message assuming the input is "Apple"
        //                  "Invalid price: Apple."
        //            Display a message on one line
        //                  "Program terminated."
        //            Terminate the program

        
        // Step 6: Read in the price and store it in a double variable


        // Step 7: Ask for the discount rate using prompt 
        //             "Enter the discount rate: "
        //         Read in the discount rate and store it in a double variable
        //         If the discount rate is not positive
        //             Display a message on one line 
        //                   Sample message assuming the input is "-0.05"
        //                  "Discount rate must be positive: -0.05."
        //             Display a message on one line
        //                  "Program terminated."
        //             Terminate the program
        
        
        // Step 8: Calculate the discount price
        //    discount price = price * (1 - discount rate)
        
        
        // Step 9: Display the product name within double quotes 
        //         and the discount price with a dollar sign and
        //         two decimal digits
        // Sample output: 
        // The discount price for "iPad Pro" is $343.99.
        
    }
}
