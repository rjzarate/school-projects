/**
 * A Java application using class Day.
 *
 * @author  Qi Yang
 * @version 2022-09-01
 */
public class DayApp
{
    public static void main(String[] args)
    {
        Day aDay;
        Day aDay = new Day();
        System.out.println(aDay.toString());
        
    }
}
