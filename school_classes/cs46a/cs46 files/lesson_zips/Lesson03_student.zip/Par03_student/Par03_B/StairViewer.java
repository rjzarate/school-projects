/**
 * Draws a staircase with three rectangles.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class StairViewer
{

    public static void main(String[] args) 
    {
        // Step 2: Create a rectangle and draw it as the 
        //         top step of the stair 
        // location: (20, 10)
        // size: (20, 20)

        // Step 3: Create a rectangle and draw it as the 
        //         middle step of the stair 
        // location: below the top step, aligned on left
        // size: (40, 20)

        // Step 4: Create a rectangle and draw it as the 
        //         bottom step of the stair 
        // location: below the middle step, aligned on left
        // size: (60, 20)

    }
}
