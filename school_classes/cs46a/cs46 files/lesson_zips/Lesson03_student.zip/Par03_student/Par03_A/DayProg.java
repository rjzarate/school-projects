/**
 * A Java application using class Day.
 *
 * Step 1: Enter your name for @author and today's date for @version
 * @author  
 * @version 
 */
public class DayProg
{
    public static void main(String[] args)
    {
        // Step 2: Construct a Day object representing today
        //         and assign it to a variable called aDay
        
        
        // Step 3: Construct a Day object representing the day 
        //         for our Exam1 on October 6, 2022, and assign 
        //         it to a variable called examOne
        

        // Step 4: Declare three integer variables called
        //         year, month and day with initial values
        //         of 2022, 11, 15.
        
        
        // Step 5: Construct a Day object using the three variables
        //         and assign it to a variable called examTwo
        
        
        // Step 6: Display the three days on separate lines
        //         without any messages
        

        // Step 7: Display the number of days as a positive integer
        //         between the two exams with a message
        //          "Number of days between the two exams: "
        
        
        // Step 8: Declare an int variable numOfDays with an initial value of 2
        // Codecheck will use a different value to test your program.
        

        // Step 9: Call method addDays() on aDay using numOfDays as parameter
        
        
        // Step 10: Print the year, month, and day of aDay, 
        //          one value per line without any messages
        // You must call methods on aDay to get the values.

    }
}
