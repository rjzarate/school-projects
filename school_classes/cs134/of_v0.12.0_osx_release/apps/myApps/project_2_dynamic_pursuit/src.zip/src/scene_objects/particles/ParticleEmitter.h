#pragma once

#include "scene_objects/generics/Emitter.h"
#include "scene_objects/particles/Particle.h"

class ParticleEmitter : public Emitter
{
public:
    void spawnSprite();
};