#pragma once

#include "scene_objects/generics/Sprite.h"

class Particle : public Sprite {
public:
	Particle();

	void update();
};