-- Function to calculate the area of a rectangle
rectangleArea :: Float -> Float -> Float
rectangleArea length width = length * width

-- Function to calculate the area of a square
squareArea :: Float -> Float
squareArea length = length * length



-- Function to calculate the area of a triangle given base and height
triangleArea :: Float -> Float -> Float
triangleArea base height = base * height * 0.5



-- Example usage
main :: IO ()
main = do
    let length = 5.0
        width = 3.0
        side = 4.0
        base = 6.0
        height = 7.0
    putStrLn $ "Area of rectangle with length " ++ show length ++ " and width " ++ show width ++ " is: " ++ show (rectangleArea length width)
    putStrLn $ "Area of square with side " ++ show side ++ " is: " ++ show (squareArea side)
    putStrLn $ "Area of triangle with base " ++ show base ++ " and height " ++ show height ++ " is: " ++ show (triangleArea base height)
