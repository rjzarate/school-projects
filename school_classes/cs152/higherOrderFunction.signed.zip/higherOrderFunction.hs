map' :: (a -> b) -> [a] -> [b]
--implement map' similar to how map in haskell
--is implemented
map' f [] = []
map' f (x:xs) = f x : map' f xs

--Using map', make a function that
--converts a list of numbers to strings.
--DO IT IN ONE LINE!!!

numsToStrings :: (Num a, Show a) => [a] -> [String]
numsToStrings list = map' (show) list



zipWith' :: (a -> b -> c) -> [a] -> [b] -> [c]
--implement zipWith' similar to how zipWith in haskell
--is implemented
zipWith' _ [] _ = []
zipWith' _ _ [] = []
zipWith' f (x:xs) (y:ys) = f x y : zipWith' f xs ys

--Using zipWith', make a function that
--takes two list, firstName and lastName.
--and output a list of full names
--Use the helper function, joinNames
--DO IT IN ONE LINE!!!

joinNames first last = first ++ " " ++ last

makeFullName :: [String] -> [String] -> [String]
makeFullName str1 str2 = zipWith' joinNames str1 str2


main :: IO ()
main = do
  putStrLn (show (map' (+3) [1,5,3,1,6]))
  putStrLn $ show $ map' fst [(1,2),(3,5),(6,3),(2,6),(2,5)] --notice the $
  putStrLn $ show $ zipWith' (*) [1,2,3,4][4,3,2,1]
  putStrLn $ show $ numsToStrings [1,5,3,1,6]
  putStrLn $ show $ makeFullName ["Michael", "Pontiac", "Hugh"] ["Scott", "Bandit", "Mungus"]
