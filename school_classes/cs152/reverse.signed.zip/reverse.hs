-- Function to reverse a list
reverseList :: [a] -> [a]
reverseList [] = []
reverseList (x:xs) = reverseList(xs) ++ [x]
  

-- Function to add corresponding elements of two lists
addTwoLists :: Num a => [a] -> [a] -> [a]
addTwoLists [] l2 = l2
addTwoLists l1 [] = l1
addTwoLists (x:xs) (y:ys) = [x + y] ++ addTwoLists xs ys

-- Function to filter positive numbers from a list
positiveNumsOnly :: (Num a, Ord a) => [a] -> [a]
positiveNumsOnly [] = []
positiveNumsOnly (x:xs)
 | x <= 0 = positiveNumsOnly(xs)
 | otherwise = [x] ++ positiveNumsOnly(xs)


main :: IO ()
main = do
    let myList1 = [1, 2, 3, 4, 5]
        myList2 = [-1, -2, -3, -4, -5]
    putStrLn $ "Reversed list 1: " ++ show (reverseList myList1)
    putStrLn $ "Reversed list 2: " ++ show (reverseList myList2)

    let list1 = [1, 2, 1, 4]
        list2 = [5, 3, 7]
    putStrLn $ "Combined list: " ++ show (addTwoLists list1 list2)

    let myList = [-3, 5, -9, 10, 0, 3, -2]
    putStrLn $ "Positive numbers only: " ++ show (positiveNumsOnly myList)
