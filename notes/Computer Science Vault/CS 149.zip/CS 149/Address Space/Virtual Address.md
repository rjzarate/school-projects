Allows for pointer arithmetic and isolation
