Privilege commands that allows the **user to have kernel privilege**
- Printing and creating files are system calls!
## Virtual Machines
System calls would have to be made from scratch so they can be send to your main machine
## System Calls v. Library Functions
System calls are provided by the kernel
Library functions are provided by the C library
- Can still use system calls and can directly make system calls