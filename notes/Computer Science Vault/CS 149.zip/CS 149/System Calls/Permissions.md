**9 Distinct** Permissions
All files could have:
1. Read
2. Write
3. Execute

Have user permissions:
4. User
5. Group
6. Other perms

Made in 6 bits