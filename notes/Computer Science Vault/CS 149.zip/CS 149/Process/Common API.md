5 APIs:
1. Create
2. Destroy
3. Wait
4. Status
5. Miscellaneous Control