Inter-Process = Between Processes
- *Intra- means inside*

**Send information to another process!**
- Interprocess communication IPC: **communicating between 2 processes**

## Why to NOT Use Temporary Files
1. Very slow!
2. A process has to finish writing on the temp file before another process can read it
3. Can create very big files
4. Have to delete the files

