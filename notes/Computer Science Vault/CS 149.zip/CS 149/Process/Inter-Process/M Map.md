Can be used for Bi-directional communcation (shared)
