1 is the lowest PID for all processes
- 0 is PID of kernel

## Functions
### `getpid()`
Gets process id
#### `getppid()`
Gets **parent** process id
