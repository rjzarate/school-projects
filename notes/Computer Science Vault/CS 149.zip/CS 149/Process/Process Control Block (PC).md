C-structure that contains information about each process

Stores:
1. id
2. stack
3. status (running/block/ready)
4. priority
5. registers (PC)
6. open files
