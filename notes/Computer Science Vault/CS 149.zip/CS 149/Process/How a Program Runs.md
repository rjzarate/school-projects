Program is loaded into memory, creating a [[Process]].
- Every process has a parent
- Every process returns an exit code
Stack is allocated
Heap is created
- Heap space is given through malloc() & free()
Does others stuff
- I/O (stdin, stdout, stderr); these files are like a buffer, will only exist in memory!

