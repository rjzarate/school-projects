a collection of programs 
provides user-interface
is a resource manager

Doesn't have **ALL** application programs (i.e. browser)

Handles: **interrupts** or **signals** that are triggered by either **hardware** (peripherals) or **software**
- Typing on the keyboard

## Operating System Model
The model had 3 layers:
1. [[Kernel]] Layer
2. [[Service]] Layer
3. [[User Interface]] Layer