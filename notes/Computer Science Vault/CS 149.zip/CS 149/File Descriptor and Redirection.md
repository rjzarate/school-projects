## `1> FILE`
Puts the **standard output** in the given `FILE`
- Also be done as `> FILE`

Will **not print anything in the terminal**
## `2> FILE`
Puts the **standard error** in the given `FILE`

Will **not print anything in the terminal**