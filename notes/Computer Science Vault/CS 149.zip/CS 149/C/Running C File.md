#### 1. Create Object File
```
gcc -o object_file_name c_file_name.c
```
#### 2. Run Object File
```
./object_file_name
```