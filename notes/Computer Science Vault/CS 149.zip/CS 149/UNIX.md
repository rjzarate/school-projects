## Linux-Based Systems
Android and iOS
## UNIX Kernel Layer
Uses C program to manipulate the system
Manages **ALL** the hardware dependent function
- Uses "Kernel Mode"
## Open Source Systems
Not always more secure than commercial or closed systems
Source code is freely available to read
All Linux systems are open source
- A custom build of a Linux operating system is called a [[Distribution]]