Creates new file descriptors for the same file
- Good for multiple users who need access for the same file