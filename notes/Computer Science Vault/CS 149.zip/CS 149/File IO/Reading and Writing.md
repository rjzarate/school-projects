Both take:
1. File description
2. The buffer
3. How many bytes to read