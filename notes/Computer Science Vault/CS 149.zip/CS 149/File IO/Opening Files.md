## `fopen` v. `open`
`open` returns the file descriptor (int)
- Used for `lseek`
`fopen` returns the file pointer