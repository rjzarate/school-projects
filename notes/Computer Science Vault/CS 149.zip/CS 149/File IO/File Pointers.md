Points to where the file is reading or riding
Also known as offset pointer (offset of the start)
## `lseek`
Changes where the offset pointer